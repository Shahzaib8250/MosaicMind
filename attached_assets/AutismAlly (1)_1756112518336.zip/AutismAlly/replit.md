# AutismConnect Platform

## Overview

AutismConnect is a comprehensive full-stack web application designed to support families affected by autism. The platform provides progress tracking tools, educational resources, community support features, and professional services booking. Built with a modern React frontend and Express.js backend, it serves as a centralized hub for autism-related resources and family support.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript and Vite for fast development and building
- **Routing**: Wouter for lightweight client-side routing
- **UI Framework**: Tailwind CSS with shadcn/ui component library for consistent design
- **State Management**: TanStack React Query for server state management and caching
- **Styling**: CSS variables for theming with glass-effect design patterns and gradient-based color schemes

### Backend Architecture
- **Framework**: Express.js with TypeScript for type-safe server development
- **API Design**: RESTful API architecture with structured route handling
- **Error Handling**: Centralized error middleware with proper HTTP status codes
- **Development**: Hot-reload development server with integrated Vite middleware
- **Build System**: ESBuild for production bundling with external package optimization

### Data Layer
- **ORM**: Drizzle ORM for type-safe database operations and schema management
- **Database**: PostgreSQL with Neon serverless database hosting
- **Schema**: Comprehensive data models for users, blog posts, resources, testimonials, support groups, contact submissions, and newsletter subscriptions
- **Storage Interface**: Abstract storage interface pattern allowing for future database migrations

### Authentication & Security
- **Session Management**: PostgreSQL-backed session storage using connect-pg-simple
- **Data Validation**: Zod schema validation integrated with Drizzle for type-safe data operations
- **Environment Configuration**: Environment-based database URL configuration

### Application Features
- **Content Management**: Blog posts with categories, featured content, and author information
- **Resource Library**: Categorized educational materials with age group filtering and download tracking
- **Community Platform**: Support groups with location-based filtering and member management
- **User Testimonials**: Rating system with featured testimonial highlighting
- **Contact System**: Form submissions and newsletter subscription management
- **Progress Tracking**: Tools for monitoring developmental milestones and therapy goals

## External Dependencies

### Core Infrastructure
- **Neon Database**: Serverless PostgreSQL hosting with automatic scaling
- **Replit Platform**: Development environment with integrated deployment and error handling

### UI and Design
- **Radix UI**: Accessible component primitives for complex UI patterns
- **Tailwind CSS**: Utility-first CSS framework with custom design tokens
- **Lucide Icons**: Consistent icon library for interface elements
- **Google Fonts**: Inter font family for typography consistency

### Development Tools
- **TypeScript**: Type safety across frontend and backend
- **Vite**: Build tool with fast development server and hot module replacement
- **ESBuild**: Fast bundling for production builds
- **Drizzle Kit**: Database migration and schema management tools

### Data Management
- **TanStack React Query**: Caching, synchronization, and background data fetching
- **React Hook Form**: Form handling with validation integration
- **Date-fns**: Date manipulation and formatting utilities

### Enhanced Features
- **Embla Carousel**: Touch-friendly carousel components for testimonials and resources
- **Class Variance Authority**: Type-safe component variant management
- **CMDK**: Command palette interface for enhanced navigation