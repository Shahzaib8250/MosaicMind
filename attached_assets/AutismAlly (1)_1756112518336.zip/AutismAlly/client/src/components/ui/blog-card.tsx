import { Button } from "@/components/ui/button";
import { Clock } from "lucide-react";

interface BlogCardProps {
  title: string;
  excerpt: string;
  category: string;
  author: string;
  authorRole: string;
  imageUrl?: string;
  readTime: number;
  publishedAt: string;
  featured?: boolean;
}

export function BlogCard({ 
  title, 
  excerpt, 
  category, 
  author, 
  authorRole,
  imageUrl, 
  readTime, 
  publishedAt,
  featured = false 
}: BlogCardProps) {
  const getCategoryColor = (cat: string) => {
    const colors: Record<string, string> = {
      Communication: "bg-primary/10 text-primary",
      Therapy: "bg-secondary/10 text-secondary",
      Education: "bg-accent/10 text-accent",
      "Success Story": "bg-green-100 text-green-700",
      Research: "bg-purple-100 text-purple-700",
      Family: "bg-pink-100 text-pink-700",
      Technology: "bg-blue-100 text-blue-700",
    };
    return colors[cat] || "bg-gray-100 text-gray-700";
  };

  return (
    <article className="bg-white rounded-xl shadow-lg overflow-hidden hover-lift">
      <div className="relative">
        <img 
          src={imageUrl || "https://images.unsplash.com/photo-1527689368864-3a821dbccc34?ixlib=rb-4.0.3&w=400&h=200&fit=crop"} 
          alt={title} 
          className="w-full h-48 object-cover" 
        />
        {featured && (
          <span className="absolute top-4 left-4 bg-primary text-white px-3 py-1 rounded-full text-sm">
            Featured
          </span>
        )}
      </div>
      <div className="p-6">
        <div className="flex items-center justify-between mb-3">
          <span className={`px-3 py-1 rounded-full text-sm ${getCategoryColor(category)}`}>
            {category}
          </span>
          <span className="text-gray-500 text-sm">{publishedAt}</span>
        </div>
        <h3 className="text-xl font-semibold text-deep-gray mb-3">{title}</h3>
        <p className="text-gray-600 mb-4">{excerpt}</p>
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <Clock className="w-4 h-4 text-gray-400" />
            <span className="text-sm text-gray-500">{readTime} min read</span>
          </div>
          <Button variant="link" className="text-primary hover:underline font-medium p-0">
            Read More
          </Button>
        </div>
        {(author || authorRole) && (
          <div className="mt-4 pt-4 border-t border-gray-100">
            <p className="text-sm text-gray-600">
              By <span className="font-medium">{author}</span>
              {authorRole && <span className="text-gray-500"> • {authorRole}</span>}
            </p>
          </div>
        )}
      </div>
    </article>
  );
}
