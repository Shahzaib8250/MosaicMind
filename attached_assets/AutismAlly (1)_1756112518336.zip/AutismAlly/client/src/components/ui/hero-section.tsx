import { Button } from "@/components/ui/button";
import { Play, Download } from "lucide-react";

interface HeroSectionProps {
  title: string;
  highlightText: string;
  subtitle: string;
  description: string;
  primaryButtonText?: string;
  secondaryButtonText?: string;
  imageUrl?: string;
  onPrimaryClick?: () => void;
  onSecondaryClick?: () => void;
}

export function HeroSection({
  title,
  highlightText,
  subtitle,
  description,
  primaryButtonText = "Download the App",
  secondaryButtonText = "Watch Demo",
  imageUrl,
  onPrimaryClick,
  onSecondaryClick,
}: HeroSectionProps) {
  return (
    <section className="relative overflow-hidden bg-gradient-to-br from-primary/10 via-secondary/5 to-transparent min-h-screen flex items-center pt-16">
      <div className="absolute inset-0 bg-gradient-to-r from-primary/5 to-secondary/5"></div>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <div className="animate-fade-in">
            <h1 className="text-4xl md:text-6xl font-bold text-deep-gray mb-6 leading-tight">
              {title}{" "}
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-primary to-secondary">
                {highlightText}
              </span>
              {subtitle && ` ${subtitle}`}
            </h1>
            <p className="text-xl text-gray-600 mb-8 leading-relaxed">
              {description}
            </p>
            <div className="flex flex-col sm:flex-row gap-4">
              <Button 
                className="bg-gradient-to-r from-primary to-primary-light text-white px-8 py-4 h-auto text-lg font-medium hover-lift transition-all duration-300"
                onClick={onPrimaryClick}
                data-testid="button-hero-primary"
              >
                <Download className="w-5 h-5 mr-2" />
                {primaryButtonText}
              </Button>
              <Button 
                variant="outline"
                className="bg-white/80 backdrop-blur-sm text-deep-gray px-8 py-4 h-auto text-lg font-medium hover-lift transition-all duration-300 border border-soft-gray"
                onClick={onSecondaryClick}
                data-testid="button-hero-secondary"
              >
                <Play className="w-5 h-5 mr-2" />
                {secondaryButtonText}
              </Button>
            </div>
          </div>
          <div className="relative animate-float">
            <div className="relative mx-auto w-80 h-96 bg-gradient-to-br from-gray-800 to-gray-900 rounded-3xl p-2 shadow-2xl">
              <div className="w-full h-full bg-white rounded-2xl overflow-hidden">
                <img 
                  src={imageUrl || "https://images.unsplash.com/photo-1559757148-5c350d0d3c56?ixlib=rb-4.0.3&w=800&h=1000&fit=crop"} 
                  alt="AutismConnect App Dashboard" 
                  className="w-full h-full object-cover" 
                />
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
