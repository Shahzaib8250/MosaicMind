import { Star } from "lucide-react";

interface TestimonialCardProps {
  name: string;
  role: string;
  content: string;
  rating: number;
  imageUrl?: string;
}

export function TestimonialCard({ name, role, content, rating, imageUrl }: TestimonialCardProps) {
  return (
    <div className="bg-white/80 backdrop-blur-sm rounded-2xl p-8 shadow-lg hover-lift">
      <div className="flex items-center mb-6">
        <img 
          src={imageUrl || "https://images.unsplash.com/photo-1544005313-94ddf0286df2?ixlib=rb-4.0.3&w=100&h=100&fit=crop"} 
          alt={`${name}, ${role}`} 
          className="w-16 h-16 rounded-full object-cover" 
        />
        <div className="ml-4">
          <h4 className="font-semibold text-deep-gray">{name}</h4>
          <p className="text-gray-600">{role}</p>
        </div>
      </div>
      <p className="text-gray-700 italic mb-4">"{content}"</p>
      <div className="flex">
        {[...Array(rating)].map((_, i) => (
          <Star key={i} className="w-4 h-4 text-yellow-400 fill-current" />
        ))}
      </div>
    </div>
  );
}
