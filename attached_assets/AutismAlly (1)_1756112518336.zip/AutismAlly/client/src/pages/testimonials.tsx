import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { TestimonialCard } from "@/components/ui/testimonial-card";
import { GlassCard } from "@/components/ui/glass-card";
import { 
  Star, 
  Quote, 
  Heart, 
  Users, 
  TrendingUp, 
  Award,
  Filter,
  Search,
  Plus
} from "lucide-react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

export default function Testimonials() {
  const [selectedCategory, setSelectedCategory] = useState("All Stories");
  const [searchTerm, setSearchTerm] = useState("");
  const [showSubmissionForm, setShowSubmissionForm] = useState(false);
  const [formData, setFormData] = useState({
    name: "",
    role: "",
    content: "",
    rating: 5,
    email: ""
  });

  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: testimonials = [], isLoading } = useQuery({
    queryKey: ["/api/testimonials"],
  });

  const { data: featuredTestimonials = [] } = useQuery({
    queryKey: ["/api/testimonials/featured"],
  });

  const testimonialMutation = useMutation({
    mutationFn: (data: any) => apiRequest("POST", "/api/testimonials", data),
    onSuccess: () => {
      toast({
        title: "Thank you for sharing!",
        description: "Your story has been submitted and will be reviewed before publishing.",
      });
      setFormData({
        name: "",
        role: "",
        content: "",
        rating: 5,
        email: ""
      });
      setShowSubmissionForm(false);
      queryClient.invalidateQueries({ queryKey: ["/api/testimonials"] });
    },
    onError: () => {
      toast({
        title: "Submission failed",
        description: "Please try again later.",
        variant: "destructive",
      });
    },
  });

  const categories = [
    "All Stories",
    "Parents",
    "Professionals", 
    "Educators",
    "Therapists",
    "Success Stories",
    "App Reviews",
    "Community Impact"
  ];

  // Sample testimonials for demonstration
  const sampleTestimonials = [
    {
      id: "1",
      name: "Sarah M.",
      role: "Parent of 7-year-old",
      content: "This app has been a game-changer for our family. The progress tracking helps us see how far my son has come, and the community support is invaluable. We've connected with other families going through similar experiences, and it's made us feel less alone in this journey.",
      rating: 5,
      imageUrl: "https://images.unsplash.com/photo-1544005313-94ddf0286df2?ixlib=rb-4.0.3&w=100&h=100&fit=crop",
      featured: true,
      category: "Parents"
    },
    {
      id: "2",
      name: "Dr. James L.",
      role: "Behavioral Therapist",
      content: "I recommend AutismConnect to all my clients' families. The resources are evidence-based and the tracking tools help me provide better care. The data visualization features make it easy to share progress with parents and adjust treatment plans accordingly.",
      rating: 5,
      imageUrl: "https://images.unsplash.com/photo-1582750433449-648ed127bb54?ixlib=rb-4.0.3&w=100&h=100&fit=crop",
      featured: true,
      category: "Professionals"
    },
    {
      id: "3",
      name: "Maria R.",
      role: "Special Education Teacher",
      content: "The educational resources are fantastic! I use them in my classroom and share them with parents. It's created a wonderful bridge between home and school. The visual supports library has been particularly helpful for my students.",
      rating: 5,
      imageUrl: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-4.0.3&w=100&h=100&fit=crop",
      featured: true,
      category: "Educators"
    },
    {
      id: "4",
      name: "Jennifer and Mike K.",
      role: "Parents of twins with autism",
      content: "Managing resources for two children with different needs was overwhelming until we found AutismConnect. The personalized dashboards for each child and the ability to track different goals simultaneously has been life-changing.",
      rating: 5,
      imageUrl: "https://images.unsplash.com/photo-1571019613454-1cb2f99b2d8b?ixlib=rb-4.0.3&w=100&h=100&fit=crop",
      featured: false,
      category: "Parents"
    },
    {
      id: "5",
      name: "Dr. Lisa Chen",
      role: "Speech-Language Pathologist",
      content: "The communication tracking features are incredibly detailed and helpful. I can see exactly what parents are working on at home and coordinate our therapy goals accordingly. It's improved collaboration significantly.",
      rating: 5,
      imageUrl: "https://images.unsplash.com/photo-1580489944761-15a19d654956?ixlib=rb-4.0.3&w=100&h=100&fit=crop",
      featured: false,
      category: "Therapists"
    },
    {
      id: "6",
      name: "Robert D.",
      role: "Father of 12-year-old",
      content: "My son went from being completely nonverbal to using over 50 words consistently. The visual communication tools and progress tracking helped us celebrate every milestone. We couldn't have done it without this support system.",
      rating: 5,
      imageUrl: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-4.0.3&w=100&h=100&fit=crop",
      featured: false,
      category: "Success Stories"
    },
    {
      id: "7",
      name: "Amanda T.",
      role: "Occupational Therapist",
      content: "The sensory tracking features are amazing. Parents can log sensory activities and reactions, which gives me valuable data to inform our therapy sessions. It's revolutionized how I approach treatment planning.",
      rating: 5,
      imageUrl: "https://images.unsplash.com/photo-1551836022-d5d88e9218df?ixlib=rb-4.0.3&w=100&h=100&fit=crop",
      featured: false,
      category: "Therapists"
    },
    {
      id: "8",
      name: "The Johnson Family",
      role: "Community members since 2022",
      content: "The support groups we found through AutismConnect have become like extended family. We've made lifelong friendships and found mentors who've walked this path before us. The community aspect is truly special.",
      rating: 5,
      imageUrl: "https://images.unsplash.com/photo-1511632765486-a01980e01a18?ixlib=rb-4.0.3&w=100&h=100&fit=crop",
      featured: false,
      category: "Community Impact"
    }
  ];

  const testimonialsToDisplay = testimonials.length > 0 ? testimonials : sampleTestimonials;
  const featuredToDisplay = featuredTestimonials.length > 0 ? featuredTestimonials : sampleTestimonials.filter(t => t.featured);

  const filteredTestimonials = testimonialsToDisplay.filter((testimonial: any) => {
    const matchesCategory = selectedCategory === "All Stories" || testimonial.category === selectedCategory;
    const matchesSearch = testimonial.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         testimonial.content.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         testimonial.role.toLowerCase().includes(searchTerm.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    testimonialMutation.mutate(formData);
  };

  const stats = [
    { icon: Star, label: "Average Rating", value: "4.9/5" },
    { icon: Users, label: "Stories Shared", value: "850+" },
    { icon: Heart, label: "Families Helped", value: "12,000+" },
    { icon: TrendingUp, label: "Success Rate", value: "95%" }
  ];

  return (
    <div className="pt-16">
      <section className="py-20 bg-gradient-to-br from-warm-gray to-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h1 className="text-4xl md:text-5xl font-bold text-deep-gray mb-6">Success Stories & Testimonials</h1>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Real stories from families, professionals, and community members who've found support and progress with AutismConnect
            </p>
          </div>

          {/* Impact Stats */}
          <div className="grid md:grid-cols-4 gap-6 mb-16">
            {stats.map((stat, index) => (
              <GlassCard key={index} className="text-center">
                <stat.icon className="w-12 h-12 text-primary mx-auto mb-4" />
                <div className="text-2xl font-bold text-deep-gray mb-2">{stat.value}</div>
                <div className="text-gray-600">{stat.label}</div>
              </GlassCard>
            ))}
          </div>

          {/* Featured Testimonials */}
          <div className="mb-16">
            <h2 className="text-3xl font-bold text-deep-gray text-center mb-12 flex items-center justify-center">
              <Award className="w-8 h-8 text-primary mr-3" />
              Featured Stories
            </h2>
            <div className="grid md:grid-cols-3 gap-8">
              {featuredToDisplay.slice(0, 3).map((testimonial: any) => (
                <div key={testimonial.id} className="relative">
                  <div className="absolute -top-2 -right-2 z-10">
                    <div className="bg-primary text-white rounded-full p-2">
                      <Star className="w-4 h-4 fill-current" />
                    </div>
                  </div>
                  <TestimonialCard
                    name={testimonial.name}
                    role={testimonial.role}
                    content={testimonial.content}
                    rating={testimonial.rating}
                    imageUrl={testimonial.imageUrl}
                  />
                </div>
              ))}
            </div>
          </div>

          {/* Search and Filter */}
          <div className="mb-12">
            <div className="bg-white rounded-2xl shadow-lg p-6 mb-8">
              <div className="flex flex-col md:flex-row gap-4">
                <div className="flex-1 relative">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
                  <Input
                    placeholder="Search stories..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="pl-10"
                    data-testid="input-search-testimonials"
                  />
                </div>
                <div className="flex gap-4">
                  <Select value={selectedCategory} onValueChange={setSelectedCategory}>
                    <SelectTrigger className="w-48" data-testid="select-category">
                      <SelectValue placeholder="All Stories" />
                    </SelectTrigger>
                    <SelectContent>
                      {categories.map((category) => (
                        <SelectItem key={category} value={category}>
                          {category}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <Button 
                    onClick={() => setShowSubmissionForm(!showSubmissionForm)}
                    className="bg-secondary text-white hover:bg-secondary/90"
                    data-testid="button-share-story"
                  >
                    <Plus className="w-4 h-4 mr-2" />
                    Share Your Story
                  </Button>
                </div>
              </div>
            </div>

            {/* Category Filter Buttons */}
            <div className="flex flex-wrap justify-center gap-3">
              {categories.map((category) => (
                <Button
                  key={category}
                  variant={selectedCategory === category ? "default" : "outline"}
                  onClick={() => setSelectedCategory(category)}
                  className={`hover-lift transition-all duration-300 ${
                    selectedCategory === category 
                      ? 'bg-primary text-white' 
                      : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                  }`}
                  data-testid={`button-category-${category.toLowerCase().replace(/\s+/g, '-')}`}
                >
                  {category}
                </Button>
              ))}
            </div>
          </div>

          {/* Story Submission Form */}
          {showSubmissionForm && (
            <div className="mb-16">
              <GlassCard className="max-w-2xl mx-auto">
                <h3 className="text-2xl font-bold text-deep-gray mb-6 flex items-center">
                  <Quote className="w-6 h-6 text-primary mr-3" />
                  Share Your Story
                </h3>
                <form onSubmit={handleSubmit} className="space-y-4">
                  <div className="grid md:grid-cols-2 gap-4">
                    <Input
                      placeholder="Your Name"
                      value={formData.name}
                      onChange={(e) => setFormData({...formData, name: e.target.value})}
                      data-testid="input-story-name"
                      required
                    />
                    <Input
                      placeholder="Your Role (e.g., Parent, Teacher)"
                      value={formData.role}
                      onChange={(e) => setFormData({...formData, role: e.target.value})}
                      data-testid="input-story-role"
                      required
                    />
                  </div>
                  <Input
                    type="email"
                    placeholder="Email (for follow-up, not public)"
                    value={formData.email}
                    onChange={(e) => setFormData({...formData, email: e.target.value})}
                    data-testid="input-story-email"
                    required
                  />
                  <Textarea
                    placeholder="Share your story... How has AutismConnect helped you and your family?"
                    rows={6}
                    value={formData.content}
                    onChange={(e) => setFormData({...formData, content: e.target.value})}
                    data-testid="textarea-story-content"
                    required
                  />
                  <div className="flex items-center space-x-4">
                    <label className="text-gray-700 font-medium">Rate your experience:</label>
                    <div className="flex space-x-1">
                      {[1, 2, 3, 4, 5].map((rating) => (
                        <button
                          key={rating}
                          type="button"
                          onClick={() => setFormData({...formData, rating})}
                          className={`w-6 h-6 ${rating <= formData.rating ? 'text-yellow-400' : 'text-gray-300'}`}
                          data-testid={`button-rating-${rating}`}
                        >
                          <Star className="w-full h-full fill-current" />
                        </button>
                      ))}
                    </div>
                  </div>
                  <div className="flex gap-4">
                    <Button 
                      type="submit"
                      className="flex-1 bg-primary text-white hover:bg-primary/90"
                      disabled={testimonialMutation.isPending}
                      data-testid="button-submit-story"
                    >
                      {testimonialMutation.isPending ? "Submitting..." : "Submit Story"}
                    </Button>
                    <Button 
                      type="button"
                      variant="outline"
                      onClick={() => setShowSubmissionForm(false)}
                      data-testid="button-cancel-story"
                    >
                      Cancel
                    </Button>
                  </div>
                </form>
              </GlassCard>
            </div>
          )}

          {/* All Testimonials */}
          <div className="mb-16">
            <h2 className="text-3xl font-bold text-deep-gray text-center mb-12">All Stories</h2>
            
            {isLoading ? (
              <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
                {[...Array(6)].map((_, index) => (
                  <div key={index} className="bg-white rounded-2xl p-8 shadow-lg animate-pulse">
                    <div className="flex items-center mb-6">
                      <div className="w-16 h-16 bg-gray-200 rounded-full mr-4"></div>
                      <div>
                        <div className="h-4 bg-gray-200 rounded w-24 mb-2"></div>
                        <div className="h-3 bg-gray-200 rounded w-32"></div>
                      </div>
                    </div>
                    <div className="space-y-2 mb-4">
                      <div className="h-4 bg-gray-200 rounded"></div>
                      <div className="h-4 bg-gray-200 rounded"></div>
                      <div className="h-4 bg-gray-200 rounded w-3/4"></div>
                    </div>
                    <div className="flex">
                      {[...Array(5)].map((_, i) => (
                        <div key={i} className="w-4 h-4 bg-gray-200 rounded mr-1"></div>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
                {filteredTestimonials.map((testimonial: any) => (
                  <TestimonialCard
                    key={testimonial.id}
                    name={testimonial.name}
                    role={testimonial.role}
                    content={testimonial.content}
                    rating={testimonial.rating}
                    imageUrl={testimonial.imageUrl}
                  />
                ))}
              </div>
            )}
          </div>

          {filteredTestimonials.length === 0 && !isLoading && (
            <div className="text-center py-12">
              <p className="text-gray-600 text-lg">No stories found matching your criteria.</p>
              <Button 
                onClick={() => {
                  setSelectedCategory("All Stories");
                  setSearchTerm("");
                }}
                className="mt-4"
                data-testid="button-clear-filters"
              >
                View All Stories
              </Button>
            </div>
          )}

          {/* Community Impact */}
          <div className="text-center">
            <GlassCard>
              <h2 className="text-3xl font-bold text-deep-gray mb-6">Join Our Community of Success</h2>
              <p className="text-xl text-gray-600 mb-8 max-w-3xl mx-auto">
                Every story shared helps another family feel less alone and more hopeful. Your experience could be the encouragement someone else needs today.
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <Button 
                  onClick={() => setShowSubmissionForm(true)}
                  className="bg-primary text-white hover:bg-primary/90 px-8 py-3"
                  data-testid="button-share-your-story"
                >
                  Share Your Story
                </Button>
                <Button 
                  variant="outline"
                  className="px-8 py-3"
                  data-testid="button-read-more-stories"
                >
                  Read More Stories
                </Button>
              </div>
            </GlassCard>
          </div>
        </div>
      </section>
    </div>
  );
}
