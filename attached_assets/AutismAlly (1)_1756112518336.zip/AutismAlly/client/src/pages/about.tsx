import { GlassCard } from "@/components/ui/glass-card";
import { Target, Eye, Users, Award } from "lucide-react";

export default function About() {
  const teamMembers = [
    {
      name: "Dr. Emily Chen",
      role: "Founder & CEO",
      education: "Clinical Psychology, Stanford",
      imageUrl: "https://images.unsplash.com/photo-1494790108755-2616b612b47c?ixlib=rb-4.0.3&w=300&h=300&fit=crop",
    },
    {
      name: "Michael Rodriguez",
      role: "Chief Technology Officer",
      education: "Software Engineering, MIT",
      imageUrl: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-4.0.3&w=300&h=300&fit=crop",
    },
    {
      name: "Dr. Aisha Patel",
      role: "Clinical Director",
      education: "Behavioral Analysis, UCLA",
      imageUrl: "https://images.unsplash.com/photo-1580489944761-15a19d654956?ixlib=rb-4.0.3&w=300&h=300&fit=crop",
    },
    {
      name: "David Kim",
      role: "Head of Community",
      education: "Social Work, NYU",
      imageUrl: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-4.0.3&w=300&h=300&fit=crop",
    },
  ];

  const stats = [
    { value: "10K+", label: "Families Supported" },
    { value: "50K+", label: "Resources Downloaded" },
    { value: "95%", label: "Satisfaction Rate" },
  ];

  return (
    <div className="pt-16">
      <section className="py-20 bg-gradient-to-br from-warm-gray to-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h1 className="text-4xl md:text-5xl font-bold text-deep-gray mb-6">About AutismConnect</h1>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              We're dedicated to empowering families affected by autism with comprehensive tools, resources, and community support.
            </p>
          </div>

          {/* Our Story */}
          <div className="grid lg:grid-cols-2 gap-12 items-center mb-20">
            <div>
              <h2 className="text-3xl font-bold text-deep-gray mb-6">Our Story</h2>
              <p className="text-gray-600 mb-6 leading-relaxed">
                AutismConnect was born from a personal journey. When our founder's daughter was diagnosed with autism, they experienced firsthand the challenges of navigating resources, tracking progress, and finding community support.
              </p>
              <p className="text-gray-600 mb-6 leading-relaxed">
                Frustrated by fragmented tools and isolated resources, we set out to create a comprehensive platform that brings everything together in one place. Today, we're proud to serve thousands of families worldwide.
              </p>
              <div className="flex items-center space-x-8">
                {stats.map((stat, index) => (
                  <div key={index} className="text-center">
                    <div className="text-3xl font-bold text-primary">{stat.value}</div>
                    <div className="text-gray-600">{stat.label}</div>
                  </div>
                ))}
              </div>
            </div>
            <div className="relative">
              <img 
                src="https://images.unsplash.com/photo-1511632765486-a01980e01a18?ixlib=rb-4.0.3&w=800&h=600&fit=crop" 
                alt="Community gathering of diverse families" 
                className="rounded-2xl shadow-2xl" 
              />
            </div>
          </div>

          {/* Mission & Vision */}
          <div className="grid md:grid-cols-2 gap-8 mb-20">
            <GlassCard>
              <div className="w-16 h-16 bg-gradient-to-r from-primary to-secondary rounded-2xl flex items-center justify-center mb-6">
                <Target className="text-white text-2xl w-8 h-8" />
              </div>
              <h3 className="text-2xl font-bold text-deep-gray mb-4">Our Mission</h3>
              <p className="text-gray-600 leading-relaxed">
                To provide families affected by autism with comprehensive, accessible tools and resources that empower them to track progress, access quality education, and build meaningful connections within a supportive community.
              </p>
            </GlassCard>
            
            <GlassCard>
              <div className="w-16 h-16 bg-gradient-to-r from-secondary to-accent rounded-2xl flex items-center justify-center mb-6">
                <Eye className="text-white text-2xl w-8 h-8" />
              </div>
              <h3 className="text-2xl font-bold text-deep-gray mb-4">Our Vision</h3>
              <p className="text-gray-600 leading-relaxed">
                A world where every family affected by autism has access to the tools, support, and community they need to thrive, fostering understanding, acceptance, and meaningful progress for individuals on the autism spectrum.
              </p>
            </GlassCard>
          </div>

          {/* Team Section */}
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-deep-gray mb-4">Meet Our Team</h2>
            <p className="text-xl text-gray-600">Passionate professionals dedicated to supporting the autism community</p>
          </div>
          
          <div className="grid md:grid-cols-4 gap-8">
            {teamMembers.map((member, index) => (
              <div key={index} className="text-center group">
                <div className="relative mb-4">
                  <img 
                    src={member.imageUrl}
                    alt={`${member.name}, ${member.role}`}
                    className="w-24 h-24 rounded-full mx-auto object-cover group-hover:scale-110 transition-transform duration-300" 
                  />
                </div>
                <h4 className="font-semibold text-deep-gray">{member.name}</h4>
                <p className="text-gray-600 text-sm">{member.role}</p>
                <p className="text-gray-500 text-xs mt-2">{member.education}</p>
              </div>
            ))}
          </div>

          {/* Accreditations */}
          <div className="mt-20 text-center">
            <h2 className="text-3xl font-bold text-deep-gray mb-8">Partnerships & Accreditations</h2>
            <div className="grid md:grid-cols-3 gap-8">
              <GlassCard>
                <Award className="w-12 h-12 text-primary mx-auto mb-4" />
                <h3 className="font-semibold text-deep-gray mb-2">HIPAA Compliant</h3>
                <p className="text-gray-600 text-sm">Certified healthcare data protection</p>
              </GlassCard>
              
              <GlassCard>
                <Users className="w-12 h-12 text-secondary mx-auto mb-4" />
                <h3 className="font-semibold text-deep-gray mb-2">Autism Organizations</h3>
                <p className="text-gray-600 text-sm">Partnered with leading advocacy groups</p>
              </GlassCard>
              
              <GlassCard>
                <Target className="w-12 h-12 text-accent mx-auto mb-4" />
                <h3 className="font-semibold text-deep-gray mb-2">Clinical Validation</h3>
                <p className="text-gray-600 text-sm">Evidence-based methodologies</p>
              </GlassCard>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
