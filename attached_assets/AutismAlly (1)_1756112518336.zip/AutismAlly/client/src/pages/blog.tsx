import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { BlogCard } from "@/components/ui/blog-card";
import { Search, Filter } from "lucide-react";

export default function Blog() {
  const [selectedCategory, setSelectedCategory] = useState("All Posts");
  const [searchTerm, setSearchTerm] = useState("");

  const { data: blogPosts = [], isLoading } = useQuery({
    queryKey: ["/api/blog"],
  });

  const { data: featuredPosts = [] } = useQuery({
    queryKey: ["/api/blog/featured"],
  });

  const categories = [
    "All Posts",
    "Parenting Tips",
    "Therapy Guidance", 
    "Success Stories",
    "Research & News",
    "Communication",
    "Education",
    "Family",
    "Technology"
  ];

  const filteredPosts = blogPosts.filter((post: any) => {
    const matchesCategory = selectedCategory === "All Posts" || post.category === selectedCategory;
    const matchesSearch = post.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         post.excerpt.toLowerCase().includes(searchTerm.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    });
  };

  // Sample blog posts for demonstration if API doesn't return data
  const samplePosts = [
    {
      id: "1",
      title: "5 Sensory Activities for Home Therapy",
      excerpt: "Simple, effective sensory activities you can do at home to support your child's development.",
      category: "Therapy",
      author: "Dr. Sarah Johnson",
      authorRole: "Occupational Therapist",
      imageUrl: "https://images.unsplash.com/photo-1596464716127-f2a82984de30?ixlib=rb-4.0.3&w=400&h=200&fit=crop",
      readTime: 5,
      publishedAt: "2024-03-12",
      featured: false,
    },
    {
      id: "2",
      title: "Navigating IEP Meetings Successfully",
      excerpt: "Expert tips for advocating for your child and building strong school partnerships.",
      category: "Education",
      author: "Maria Garcia",
      authorRole: "Special Education Advocate",
      imageUrl: "https://images.unsplash.com/photo-1544717297-fa95b6ee9643?ixlib=rb-4.0.3&w=400&h=200&fit=crop",
      readTime: 8,
      publishedAt: "2024-03-10",
      featured: false,
    },
    {
      id: "3",
      title: "From Nonverbal to Thriving: Jake's Journey",
      excerpt: "A mother shares her son's remarkable progress in communication and social skills.",
      category: "Success Story",
      author: "Jennifer Thompson",
      authorRole: "Parent",
      imageUrl: "https://images.unsplash.com/photo-1511632765486-a01980e01a18?ixlib=rb-4.0.3&w=400&h=200&fit=crop",
      readTime: 6,
      publishedAt: "2024-03-08",
      featured: false,
    },
    {
      id: "4",
      title: "Latest Research: Early Intervention Impact",
      excerpt: "New study reveals the long-term benefits of early intervention programs.",
      category: "Research",
      author: "Dr. Michael Chen",
      authorRole: "Research Scientist",
      imageUrl: "https://images.unsplash.com/photo-1576091160399-112ba8d25d1f?ixlib=rb-4.0.3&w=400&h=200&fit=crop",
      readTime: 12,
      publishedAt: "2024-03-05",
      featured: false,
    },
    {
      id: "5",
      title: "Supporting Siblings: Building Strong Bonds",
      excerpt: "Strategies for helping siblings understand and connect with their autistic brother or sister.",
      category: "Family",
      author: "Dr. Lisa Wang",
      authorRole: "Family Therapist",
      imageUrl: "https://images.unsplash.com/photo-1542034245-0a170bbdf8eb?ixlib=rb-4.0.3&w=400&h=200&fit=crop",
      readTime: 7,
      publishedAt: "2024-03-03",
      featured: false,
    },
    {
      id: "6",
      title: "Tech Tools for Communication Support",
      excerpt: "A comprehensive guide to apps and devices that enhance communication skills.",
      category: "Technology",
      author: "Alex Rodriguez",
      authorRole: "Assistive Technology Specialist",
      imageUrl: "https://images.unsplash.com/photo-1531297484001-80022131f5a1?ixlib=rb-4.0.3&w=400&h=200&fit=crop",
      readTime: 10,
      publishedAt: "2024-03-01",
      featured: false,
    }
  ];

  const postsToDisplay = filteredPosts.length > 0 ? filteredPosts : samplePosts;
  const featuredPost = featuredPosts.length > 0 ? featuredPosts[0] : {
    id: "featured",
    title: "Breaking Communication Barriers: Visual Supports That Work",
    excerpt: "Discover evidence-based visual communication strategies that have helped thousands of families improve daily interactions and reduce frustration.",
    category: "Communication",
    author: "Dr. Emily Carter",
    authorRole: "Speech-Language Pathologist",
    imageUrl: "https://images.unsplash.com/photo-1527689368864-3a821dbccc34?ixlib=rb-4.0.3&w=600&h=400&fit=crop",
    readTime: 8,
    publishedAt: "2024-03-15",
    featured: true,
  };

  return (
    <div className="pt-16">
      <section className="py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h1 className="text-4xl md:text-5xl font-bold text-deep-gray mb-6">Blog & Insights</h1>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Expert advice, family stories, and the latest research in autism support
            </p>
          </div>

          {/* Featured Post */}
          <div className="mb-16">
            <div className="bg-white rounded-2xl shadow-lg overflow-hidden">
              <div className="grid lg:grid-cols-2 gap-0">
                <div className="relative">
                  <img 
                    src={featuredPost.imageUrl}
                    alt={featuredPost.title}
                    className="w-full h-64 lg:h-full object-cover" 
                  />
                  <span className="absolute top-4 left-4 bg-primary text-white px-3 py-1 rounded-full text-sm">
                    Featured
                  </span>
                </div>
                <div className="p-8 lg:p-12">
                  <div className="flex items-center space-x-2 mb-4">
                    <span className="bg-primary/10 text-primary px-3 py-1 rounded-full text-sm">
                      {featuredPost.category}
                    </span>
                    <span className="text-gray-500 text-sm">
                      {formatDate(featuredPost.publishedAt)}
                    </span>
                  </div>
                  <h2 className="text-2xl lg:text-3xl font-bold text-deep-gray mb-4">
                    {featuredPost.title}
                  </h2>
                  <p className="text-gray-600 mb-6 leading-relaxed">
                    {featuredPost.excerpt}
                  </p>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-3">
                      <div className="w-10 h-10 bg-gray-200 rounded-full"></div>
                      <div>
                        <p className="font-medium text-deep-gray text-sm">{featuredPost.author}</p>
                        <p className="text-gray-500 text-xs">{featuredPost.authorRole}</p>
                      </div>
                    </div>
                    <Button 
                      className="bg-primary text-white hover:bg-primary/90 hover-lift"
                      data-testid="button-read-featured"
                    >
                      Read More
                    </Button>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Search and Categories */}
          <div className="mb-12">
            <div className="bg-white rounded-2xl shadow-lg p-6 mb-8">
              <div className="flex flex-col md:flex-row gap-4">
                <div className="flex-1 relative">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
                  <Input
                    placeholder="Search articles..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="pl-10"
                    data-testid="input-search-blog"
                  />
                </div>
                <Button 
                  variant="outline" 
                  className="flex items-center gap-2"
                  data-testid="button-filter-blog"
                >
                  <Filter className="w-4 h-4" />
                  Filter
                </Button>
              </div>
            </div>

            <div className="flex flex-wrap justify-center gap-4">
              {categories.map((category) => (
                <Button
                  key={category}
                  variant={selectedCategory === category ? "default" : "outline"}
                  onClick={() => setSelectedCategory(category)}
                  className={`hover-lift transition-all duration-300 ${
                    selectedCategory === category 
                      ? 'bg-primary text-white' 
                      : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                  }`}
                  data-testid={`button-category-${category.toLowerCase().replace(/\s+/g, '-')}`}
                >
                  {category}
                </Button>
              ))}
            </div>
          </div>

          {/* Blog Posts Grid */}
          {isLoading ? (
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
              {[...Array(6)].map((_, index) => (
                <div key={index} className="bg-white rounded-xl shadow-lg overflow-hidden animate-pulse">
                  <div className="w-full h-48 bg-gray-200"></div>
                  <div className="p-6">
                    <div className="h-4 bg-gray-200 rounded mb-3"></div>
                    <div className="h-6 bg-gray-200 rounded mb-3"></div>
                    <div className="h-16 bg-gray-200 rounded mb-4"></div>
                    <div className="h-4 bg-gray-200 rounded"></div>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
              {postsToDisplay.map((post: any) => (
                <BlogCard
                  key={post.id}
                  title={post.title}
                  excerpt={post.excerpt}
                  category={post.category}
                  author={post.author}
                  authorRole={post.authorRole}
                  imageUrl={post.imageUrl}
                  readTime={post.readTime}
                  publishedAt={formatDate(post.publishedAt)}
                  featured={post.featured}
                />
              ))}
            </div>
          )}

          {postsToDisplay.length === 0 && !isLoading && (
            <div className="text-center py-12">
              <p className="text-gray-600 text-lg">No articles found matching your criteria.</p>
              <Button 
                onClick={() => {
                  setSelectedCategory("All Posts");
                  setSearchTerm("");
                }}
                className="mt-4"
                data-testid="button-clear-filters"
              >
                Clear Filters
              </Button>
            </div>
          )}

          {/* Newsletter Signup */}
          <div className="mt-16 bg-gradient-to-r from-primary to-secondary rounded-2xl p-8 text-center">
            <h2 className="text-3xl font-bold text-white mb-4">Stay Updated</h2>
            <p className="text-white/90 mb-6">Get the latest insights and resources delivered to your inbox weekly.</p>
            <div className="max-w-md mx-auto flex gap-4">
              <Input 
                type="email" 
                placeholder="Enter your email" 
                className="flex-1 bg-white"
                data-testid="input-newsletter-email"
              />
              <Button 
                className="bg-white text-primary hover:bg-gray-100 font-medium"
                data-testid="button-newsletter-subscribe"
              >
                Subscribe
              </Button>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
