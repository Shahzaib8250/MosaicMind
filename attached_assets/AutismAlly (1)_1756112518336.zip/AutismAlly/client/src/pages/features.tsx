import { Button } from "@/components/ui/button";
import { GlassCard } from "@/components/ui/glass-card";
import { 
  TrendingUp, 
  GraduationCap, 
  Users, 
  Smartphone, 
  Calendar, 
  Shield 
} from "lucide-react";

export default function Features() {
  const mainFeatures = [
    {
      icon: TrendingUp,
      title: "Progress Tracking",
      description: "Monitor developmental milestones, therapy goals, and daily achievements with our intuitive tracking system. Visual charts and reports help you celebrate progress and identify areas for focus.",
      features: [
        "Visual milestone tracking with custom goals",
        "Behavioral data collection and analysis",
        "Shareable reports for healthcare providers",
        "Photo and video documentation",
      ],
      imageUrl: "https://images.unsplash.com/photo-1551288049-bebda4e38f71?ixlib=rb-4.0.3&w=800&h=600&fit=crop",
      gradient: "bg-gradient-to-r from-primary to-secondary",
    },
    {
      icon: GraduationCap,
      title: "Educational Resources",
      description: "Access a comprehensive library of evidence-based educational materials, therapy guides, and learning activities curated by autism experts and clinicians.",
      features: [
        "500+ expert-reviewed resources",
        "Age-appropriate content filtering",
        "Printable worksheets and activities",
        "Video tutorials and demonstrations",
      ],
      imageUrl: "https://images.unsplash.com/photo-1481627834876-b7833e8f5570?ixlib=rb-4.0.3&w=800&h=600&fit=crop",
      gradient: "bg-gradient-to-r from-secondary to-accent",
    },
    {
      icon: Users,
      title: "Community Support",
      description: "Connect with other families, join support groups, and access professional guidance in a safe, moderated environment designed for meaningful connections.",
      features: [
        "Location-based support groups",
        "Professional-moderated discussions",
        "Anonymous sharing options",
        "Expert Q&A sessions",
      ],
      imageUrl: "https://images.unsplash.com/photo-1522202176988-66273c2fd55f?ixlib=rb-4.0.3&w=800&h=600&fit=crop",
      gradient: "bg-gradient-to-r from-accent to-primary",
    },
  ];

  const additionalFeatures = [
    {
      icon: Smartphone,
      title: "Cross-Platform Sync",
      description: "Access your data across all devices with seamless synchronization.",
      color: "text-primary",
    },
    {
      icon: Calendar,
      title: "Appointment Scheduling",
      description: "Book and manage therapy sessions and medical appointments.",
      color: "text-secondary",
    },
    {
      icon: Shield,
      title: "HIPAA Compliance",
      description: "Your family's data is protected with healthcare-grade security.",
      color: "text-accent",
    },
  ];

  return (
    <div className="pt-16">
      <section className="py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h1 className="text-4xl md:text-5xl font-bold text-deep-gray mb-6">Powerful Features</h1>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Comprehensive tools designed specifically for families navigating autism, backed by clinical expertise and community insights.
            </p>
          </div>

          {/* Feature Details with Interactive Demos */}
          <div className="space-y-20">
            {mainFeatures.map((feature, index) => (
              <div key={index} className={`grid lg:grid-cols-2 gap-12 items-center ${
                index % 2 === 1 ? 'lg:flex-row-reverse' : ''
              }`}>
                <div className={index % 2 === 1 ? 'lg:order-2' : ''}>
                  <div className="flex items-center mb-6">
                    <div className={`w-16 h-16 ${feature.gradient} rounded-2xl flex items-center justify-center mr-4`}>
                      <feature.icon className="text-white text-2xl w-8 h-8" />
                    </div>
                    <h2 className="text-3xl font-bold text-deep-gray">{feature.title}</h2>
                  </div>
                  <p className="text-gray-600 mb-6 leading-relaxed">
                    {feature.description}
                  </p>
                  <ul className="space-y-3 mb-8">
                    {feature.features.map((item, itemIndex) => (
                      <li key={itemIndex} className="flex items-center text-gray-600">
                        <div className="w-2 h-2 bg-green-500 rounded-full mr-3"></div>
                        {item}
                      </li>
                    ))}
                  </ul>
                  <Button 
                    className={`${feature.gradient} text-white hover:opacity-90 transition-all duration-300`}
                    data-testid={`button-demo-${feature.title.toLowerCase().replace(' ', '-')}`}
                  >
                    Try Interactive Demo
                  </Button>
                </div>
                <div className={`relative ${index % 2 === 1 ? 'lg:order-1' : ''}`}>
                  <div className="bg-white rounded-2xl shadow-2xl p-6">
                    <img 
                      src={feature.imageUrl}
                      alt={`${feature.title} dashboard interface`}
                      className="rounded-xl w-full h-64 lg:h-80 object-cover" 
                    />
                  </div>
                </div>
              </div>
            ))}
          </div>

          {/* Additional Features Grid */}
          <div className="mt-20">
            <h2 className="text-3xl font-bold text-deep-gray text-center mb-12">Additional Features</h2>
            <div className="grid md:grid-cols-3 gap-8">
              {additionalFeatures.map((feature, index) => (
                <GlassCard key={index}>
                  <feature.icon className={`text-3xl mb-4 w-12 h-12 ${feature.color}`} />
                  <h3 className="text-xl font-semibold text-deep-gray mb-3">{feature.title}</h3>
                  <p className="text-gray-600">{feature.description}</p>
                </GlassCard>
              ))}
            </div>
          </div>

          {/* CTA Section */}
          <div className="mt-20 text-center">
            <div className="bg-gradient-to-r from-primary to-secondary rounded-2xl p-12">
              <h2 className="text-3xl font-bold text-white mb-4">Ready to Experience These Features?</h2>
              <p className="text-white/90 mb-8 text-lg">
                Download AutismConnect today and discover how these powerful tools can support your family's journey.
              </p>
              <Button 
                className="bg-white text-primary hover:bg-gray-100 px-8 py-4 h-auto text-lg font-medium"
                data-testid="button-download-features"
              >
                Download Now
              </Button>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
