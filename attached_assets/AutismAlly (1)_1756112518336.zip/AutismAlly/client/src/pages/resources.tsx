import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { GlassCard } from "@/components/ui/glass-card";
import { 
  Search, 
  Download, 
  Play, 
  ExternalLink, 
  FileText, 
  Video, 
  Link as LinkIcon,
  Star,
  Filter
} from "lucide-react";

export default function Resources() {
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("");
  const [selectedAgeGroup, setSelectedAgeGroup] = useState("");

  const { data: resources = [], isLoading } = useQuery({
    queryKey: ["/api/resources", selectedCategory, selectedAgeGroup],
  });

  const { data: popularResources = [] } = useQuery({
    queryKey: ["/api/resources/popular"],
  });

  const categories = [
    "All Categories",
    "Therapy Guides", 
    "Educational Tools",
    "Assessment Forms",
    "Family Support",
    "Communication Aids",
    "Sensory Tools",
    "Behavior Management",
    "Social Skills"
  ];

  const ageGroups = [
    "All Ages",
    "Early Childhood (2-5)",
    "School Age (6-12)", 
    "Teenagers (13-18)",
    "Adults (18+)"
  ];

  // Sample resources for demonstration
  const sampleResources = [
    {
      id: "1",
      title: "Communication Skills Workbook",
      description: "Visual communication cards and exercises for developing language skills.",
      category: "Educational Tools",
      type: "PDF",
      url: "#",
      ageGroup: "School Age (6-12)",
      rating: 4.9,
      downloads: 1250,
      imageUrl: "https://images.unsplash.com/photo-1434030216411-0b793f4b4173?ixlib=rb-4.0.3&w=400&h=200&fit=crop",
    },
    {
      id: "2", 
      title: "Sensory Play Therapy",
      description: "15-minute guide to creating sensory-rich play experiences at home.",
      category: "Therapy Guides",
      type: "Video",
      url: "#",
      ageGroup: "Early Childhood (2-5)",
      rating: 4.8,
      downloads: 892,
      imageUrl: "https://images.unsplash.com/photo-1571019613454-1cb2f99b2d8b?ixlib=rb-4.0.3&w=400&h=200&fit=crop",
    },
    {
      id: "3",
      title: "Developmental Milestones Checklist",
      description: "Comprehensive checklist for tracking developmental progress.",
      category: "Assessment Forms",
      type: "PDF",
      url: "#",
      ageGroup: "All Ages",
      rating: 4.7,
      downloads: 2100,
      imageUrl: "https://images.unsplash.com/photo-1586281380349-632531db7ed4?ixlib=rb-4.0.3&w=400&h=200&fit=crop",
    },
    {
      id: "4",
      title: "Visual Schedule Templates",
      description: "Customizable visual schedules for daily routines and activities.",
      category: "Educational Tools",
      type: "PDF",
      url: "#",
      ageGroup: "School Age (6-12)",
      rating: 4.9,
      downloads: 1680,
      imageUrl: "https://images.unsplash.com/photo-1434030216411-0b793f4b4173?ixlib=rb-4.0.3&w=400&h=200&fit=crop",
    },
    {
      id: "5",
      title: "Social Stories Collection",
      description: "Ready-to-use social stories for common situations and challenges.",
      category: "Social Skills",
      type: "PDF",
      url: "#",
      ageGroup: "School Age (6-12)",
      rating: 4.8,
      downloads: 1340,
      imageUrl: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-4.0.3&w=400&h=200&fit=crop",
    },
    {
      id: "6",
      title: "Calming Strategies Toolkit",
      description: "Evidence-based techniques for managing sensory overload and meltdowns.",
      category: "Behavior Management",
      type: "Video",
      url: "#",
      ageGroup: "All Ages",
      rating: 4.9,
      downloads: 2250,
      imageUrl: "https://images.unsplash.com/photo-1596464716127-f2a82984de30?ixlib=rb-4.0.3&w=400&h=200&fit=crop",
    }
  ];

  const filteredResources = (resources.length > 0 ? resources : sampleResources).filter((resource: any) => {
    const matchesSearch = resource.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         resource.description.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = !selectedCategory || selectedCategory === "All Categories" || resource.category === selectedCategory;
    const matchesAge = !selectedAgeGroup || selectedAgeGroup === "All Ages" || resource.ageGroup === selectedAgeGroup;
    return matchesSearch && matchesCategory && matchesAge;
  });

  const getTypeIcon = (type: string) => {
    switch (type) {
      case "PDF":
        return FileText;
      case "Video":
        return Video;
      case "Link":
        return LinkIcon;
      default:
        return FileText;
    }
  };

  const getTypeColor = (type: string) => {
    switch (type) {
      case "PDF":
        return "bg-primary/10 text-primary";
      case "Video":
        return "bg-secondary/10 text-secondary";
      case "Link":
        return "bg-accent/10 text-accent";
      default:
        return "bg-gray-100 text-gray-700";
    }
  };

  return (
    <div className="pt-16">
      <section className="py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h1 className="text-4xl md:text-5xl font-bold text-deep-gray mb-6">Resource Library</h1>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Curated tools, guides, and materials to support your autism journey
            </p>
          </div>

          {/* Search and Filter */}
          <div className="bg-white rounded-2xl shadow-lg p-6 mb-12">
            <div className="grid md:grid-cols-4 gap-4">
              <div className="md:col-span-2 relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
                <Input 
                  placeholder="Search resources..." 
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                  data-testid="input-search-resources"
                />
              </div>
              <Select value={selectedCategory} onValueChange={setSelectedCategory}>
                <SelectTrigger data-testid="select-category">
                  <SelectValue placeholder="All Categories" />
                </SelectTrigger>
                <SelectContent>
                  {categories.map((category) => (
                    <SelectItem key={category} value={category}>
                      {category}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <Select value={selectedAgeGroup} onValueChange={setSelectedAgeGroup}>
                <SelectTrigger data-testid="select-age-group">
                  <SelectValue placeholder="All Ages" />
                </SelectTrigger>
                <SelectContent>
                  {ageGroups.map((age) => (
                    <SelectItem key={age} value={age}>
                      {age}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          {/* Resource Categories Overview */}
          <div className="grid md:grid-cols-3 gap-8 mb-16">
            <GlassCard className="group cursor-pointer">
              <div className="w-16 h-16 bg-gradient-to-r from-primary to-secondary rounded-2xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform duration-300">
                <FileText className="text-white text-2xl w-8 h-8" />
              </div>
              <h3 className="text-xl font-semibold text-deep-gray mb-4">Downloadable Guides</h3>
              <p className="text-gray-600 mb-6">
                Comprehensive PDFs covering therapy techniques, educational strategies, and family support.
              </p>
              <div className="text-sm text-primary font-medium">45+ Downloads Available</div>
            </GlassCard>
            
            <GlassCard className="group cursor-pointer">
              <div className="w-16 h-16 bg-gradient-to-r from-secondary to-accent rounded-2xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform duration-300">
                <Video className="text-white text-2xl w-8 h-8" />
              </div>
              <h3 className="text-xl font-semibold text-deep-gray mb-4">Video Tutorials</h3>
              <p className="text-gray-600 mb-6">
                Step-by-step video guides for therapy exercises and educational activities.
              </p>
              <div className="text-sm text-secondary font-medium">25+ Videos Available</div>
            </GlassCard>
            
            <GlassCard className="group cursor-pointer">
              <div className="w-16 h-16 bg-gradient-to-r from-accent to-primary rounded-2xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform duration-300">
                <ExternalLink className="text-white text-2xl w-8 h-8" />
              </div>
              <h3 className="text-xl font-semibold text-deep-gray mb-4">External Resources</h3>
              <p className="text-gray-600 mb-6">
                Curated links to trusted organizations, research, and professional services.
              </p>
              <div className="text-sm text-accent font-medium">100+ Trusted Links</div>
            </GlassCard>
          </div>

          {/* Popular Resources */}
          <div className="mb-12">
            <h2 className="text-3xl font-bold text-deep-gray mb-8">Popular Resources</h2>
            
            {isLoading ? (
              <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                {[...Array(6)].map((_, index) => (
                  <div key={index} className="bg-white rounded-xl shadow-lg overflow-hidden animate-pulse">
                    <div className="w-full h-32 bg-gray-200"></div>
                    <div className="p-6">
                      <div className="h-4 bg-gray-200 rounded mb-3"></div>
                      <div className="h-6 bg-gray-200 rounded mb-3"></div>
                      <div className="h-16 bg-gray-200 rounded mb-4"></div>
                      <div className="h-10 bg-gray-200 rounded"></div>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                {filteredResources.map((resource: any) => {
                  const TypeIcon = getTypeIcon(resource.type);
                  return (
                    <div key={resource.id} className="bg-white rounded-xl shadow-lg overflow-hidden hover-lift">
                      <img 
                        src={resource.imageUrl}
                        alt={resource.title}
                        className="w-full h-32 object-cover" 
                      />
                      <div className="p-6">
                        <div className="flex items-center justify-between mb-2">
                          <span className={`px-3 py-1 rounded-full text-sm ${getTypeColor(resource.type)}`}>
                            {resource.type}
                          </span>
                          <div className="flex items-center text-yellow-400">
                            <Star className="w-4 h-4 fill-current" />
                            <span className="ml-1 text-gray-600 text-sm">{resource.rating}</span>
                          </div>
                        </div>
                        <h3 className="font-semibold text-deep-gray mb-2">{resource.title}</h3>
                        <p className="text-gray-600 text-sm mb-4">{resource.description}</p>
                        <div className="flex items-center justify-between text-sm text-gray-500 mb-4">
                          <span>{resource.downloads} downloads</span>
                          <span>{resource.ageGroup}</span>
                        </div>
                        <Button 
                          className="w-full bg-primary text-white hover:bg-primary/90"
                          data-testid={`button-download-${resource.id}`}
                        >
                          <TypeIcon className="w-4 h-4 mr-2" />
                          {resource.type === "Video" ? "Watch" : "Download"}
                        </Button>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>

          {filteredResources.length === 0 && !isLoading && (
            <div className="text-center py-12">
              <p className="text-gray-600 text-lg">No resources found matching your criteria.</p>
              <Button 
                onClick={() => {
                  setSearchTerm("");
                  setSelectedCategory("");
                  setSelectedAgeGroup("");
                }}
                className="mt-4"
                data-testid="button-clear-filters"
              >
                Clear Filters
              </Button>
            </div>
          )}

          {/* External Resources Section */}
          <div className="mt-16">
            <h2 className="text-3xl font-bold text-deep-gray mb-8">Trusted Organizations</h2>
            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
              {[
                {
                  name: "Autism Speaks",
                  description: "Leading autism advocacy organization",
                  url: "https://autismspeaks.org",
                },
                {
                  name: "Autism Society",
                  description: "Improving lives of all affected by autism",
                  url: "https://autismsociety.org",
                },
                {
                  name: "ASAN",
                  description: "Autistic Self Advocacy Network",
                  url: "https://autisticadvocacy.org",
                },
                {
                  name: "CDC Autism Info",
                  description: "Official CDC autism information",
                  url: "https://cdc.gov/autism",
                }
              ].map((org, index) => (
                <div key={index} className="bg-white rounded-xl p-6 shadow-lg hover-lift border-l-4 border-primary">
                  <h3 className="font-semibold text-deep-gray mb-2">{org.name}</h3>
                  <p className="text-gray-600 text-sm mb-4">{org.description}</p>
                  <a 
                    href={org.url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-primary hover:underline text-sm font-medium flex items-center"
                    data-testid={`link-org-${org.name.toLowerCase().replace(/\s+/g, '-')}`}
                  >
                    Visit Website
                    <ExternalLink className="w-3 h-3 ml-1" />
                  </a>
                </div>
              ))}
            </div>
          </div>

          {/* CTA Section */}
          <div className="mt-16 text-center">
            <div className="bg-gradient-to-r from-primary to-secondary rounded-2xl p-12">
              <h2 className="text-3xl font-bold text-white mb-4">Need a Specific Resource?</h2>
              <p className="text-white/90 mb-8 text-lg">
                Can't find what you're looking for? Our team is here to help you find the right resources for your needs.
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <Button 
                  className="bg-white text-primary hover:bg-gray-100 px-8 py-3"
                  data-testid="button-request-resource"
                >
                  Request a Resource
                </Button>
                <Button 
                  variant="outline"
                  className="border-white text-white hover:bg-white hover:text-primary px-8 py-3"
                  data-testid="button-contact-support"
                >
                  Contact Support
                </Button>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
