import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { GlassCard } from "@/components/ui/glass-card";
import { Link } from "wouter";
import { 
  Stethoscope, 
  GraduationCap, 
  Users, 
  Baby, 
  Newspaper, 
  HelpCircle,
  Search,
  Filter,
  ArrowRight
} from "lucide-react";

export default function Categories() {
  const mainCategories = [
    {
      icon: Stethoscope,
      title: "Therapy & Treatment",
      description: "Evidence-based therapy approaches, treatment options, and professional resources",
      count: "150+ resources",
      color: "text-primary",
      bgColor: "bg-gradient-to-r from-primary to-secondary",
      subcategories: ["Applied Behavior Analysis", "Speech Therapy", "Occupational Therapy", "Social Skills Training"],
    },
    {
      icon: GraduationCap,
      title: "Educational Tools",
      description: "Learning materials, visual supports, and educational strategies for all ages",
      count: "200+ resources",
      color: "text-secondary",
      bgColor: "bg-gradient-to-r from-secondary to-accent",
      subcategories: ["Visual Schedules", "Communication Cards", "Learning Activities", "IEP Resources"],
    },
    {
      icon: Users,
      title: "Support Groups",
      description: "Connect with families, professionals, and advocacy organizations",
      count: "50+ groups",
      color: "text-accent",
      bgColor: "bg-gradient-to-r from-accent to-primary",
      subcategories: ["Parent Groups", "Sibling Support", "Professional Networks", "Teen Groups"],
    },
    {
      icon: Baby,
      title: "Parenting Resources",
      description: "Practical guidance for daily life, behavior management, and family support",
      count: "120+ resources",
      color: "text-green-600",
      bgColor: "bg-gradient-to-r from-green-500 to-blue-500",
      subcategories: ["Daily Routines", "Behavior Strategies", "Sensory Support", "Family Planning"],
    },
    {
      icon: Newspaper,
      title: "Autism News & Research",
      description: "Latest research findings, news updates, and scientific developments",
      count: "80+ articles",
      color: "text-purple-600",
      bgColor: "bg-gradient-to-r from-purple-500 to-pink-500",
      subcategories: ["Research Studies", "Medical Updates", "Policy Changes", "Community News"],
    },
    {
      icon: HelpCircle,
      title: "App Guides & Tutorials",
      description: "Step-by-step guides to maximize your AutismConnect experience",
      count: "30+ guides",
      color: "text-indigo-600",
      bgColor: "bg-gradient-to-r from-indigo-500 to-purple-500",
      subcategories: ["Getting Started", "Advanced Features", "Troubleshooting", "Best Practices"],
    },
  ];

  const filterOptions = {
    ageGroups: ["All Ages", "Early Childhood (2-5)", "School Age (6-12)", "Teenagers (13-18)", "Adults (18+)"],
    resourceTypes: ["All Types", "Articles", "Videos", "PDFs", "Interactive Tools", "Support Groups"],
    difficulty: ["All Levels", "Beginner", "Intermediate", "Advanced"],
  };

  return (
    <div className="pt-16">
      <section className="py-20 bg-gradient-to-br from-warm-gray to-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h1 className="text-4xl md:text-5xl font-bold text-deep-gray mb-6">Resource Categories</h1>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Organize your autism support journey with our comprehensive resource categories. Find exactly what you need, when you need it.
            </p>
          </div>

          {/* Search and Filter Section */}
          <div className="bg-white rounded-2xl shadow-lg p-6 mb-12">
            <div className="grid md:grid-cols-5 gap-4">
              <div className="md:col-span-2 relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
                <Input 
                  placeholder="Search all resources..." 
                  className="pl-10"
                  data-testid="input-search-resources"
                />
              </div>
              <Select>
                <SelectTrigger data-testid="select-age-group">
                  <SelectValue placeholder="Age Group" />
                </SelectTrigger>
                <SelectContent>
                  {filterOptions.ageGroups.map((age) => (
                    <SelectItem key={age} value={age.toLowerCase().replace(/\s+/g, '-')}>
                      {age}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <Select>
                <SelectTrigger data-testid="select-resource-type">
                  <SelectValue placeholder="Resource Type" />
                </SelectTrigger>
                <SelectContent>
                  {filterOptions.resourceTypes.map((type) => (
                    <SelectItem key={type} value={type.toLowerCase().replace(/\s+/g, '-')}>
                      {type}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <Button 
                className="bg-primary text-white hover:bg-primary/90"
                data-testid="button-apply-filters"
              >
                <Filter className="w-4 h-4 mr-2" />
                Filter
              </Button>
            </div>
          </div>

          {/* Main Categories Grid */}
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8 mb-16">
            {mainCategories.map((category, index) => (
              <GlassCard key={index} className="group cursor-pointer">
                <div className="flex items-start justify-between mb-6">
                  <div className={`w-16 h-16 ${category.bgColor} rounded-2xl flex items-center justify-center group-hover:scale-110 transition-transform duration-300`}>
                    <category.icon className="text-white w-8 h-8" />
                  </div>
                  <ArrowRight className="text-gray-400 group-hover:text-primary transition-colors duration-300 w-5 h-5" />
                </div>
                <h3 className="text-xl font-semibold text-deep-gray mb-3">{category.title}</h3>
                <p className="text-gray-600 mb-4">{category.description}</p>
                <div className="text-sm font-medium text-primary mb-4">{category.count}</div>
                <div className="space-y-2">
                  <p className="text-sm font-medium text-gray-700">Popular subcategories:</p>
                  <div className="flex flex-wrap gap-2">
                    {category.subcategories.slice(0, 2).map((sub, subIndex) => (
                      <span 
                        key={subIndex}
                        className="bg-gray-100 text-gray-600 px-3 py-1 rounded-full text-xs"
                      >
                        {sub}
                      </span>
                    ))}
                    {category.subcategories.length > 2 && (
                      <span className="bg-gray-100 text-gray-600 px-3 py-1 rounded-full text-xs">
                        +{category.subcategories.length - 2} more
                      </span>
                    )}
                  </div>
                </div>
              </GlassCard>
            ))}
          </div>

          {/* Quick Access Filters */}
          <div className="bg-gradient-to-r from-primary/5 to-secondary/5 rounded-2xl p-8">
            <h2 className="text-2xl font-bold text-deep-gray mb-6 text-center">Quick Access Filters</h2>
            <div className="grid md:grid-cols-3 gap-6">
              <div>
                <h3 className="font-semibold text-deep-gray mb-3">By Age Group</h3>
                <div className="space-y-2">
                  {filterOptions.ageGroups.slice(1).map((age, index) => (
                    <Link 
                      key={index}
                      href={`/resources?age=${age.toLowerCase().replace(/\s+/g, '-')}`}
                      className="block text-gray-600 hover:text-primary transition-colors duration-300"
                      data-testid={`link-age-${age.toLowerCase().replace(/\s+/g, '-')}`}
                    >
                      {age}
                    </Link>
                  ))}
                </div>
              </div>
              <div>
                <h3 className="font-semibold text-deep-gray mb-3">By Resource Type</h3>
                <div className="space-y-2">
                  {filterOptions.resourceTypes.slice(1).map((type, index) => (
                    <Link 
                      key={index}
                      href={`/resources?type=${type.toLowerCase().replace(/\s+/g, '-')}`}
                      className="block text-gray-600 hover:text-primary transition-colors duration-300"
                      data-testid={`link-type-${type.toLowerCase().replace(/\s+/g, '-')}`}
                    >
                      {type}
                    </Link>
                  ))}
                </div>
              </div>
              <div>
                <h3 className="font-semibold text-deep-gray mb-3">Popular Tags</h3>
                <div className="flex flex-wrap gap-2">
                  {["ABA Therapy", "Visual Supports", "Sensory Tools", "IEP Planning", "Social Skills", "Communication"].map((tag, index) => (
                    <Link 
                      key={index}
                      href={`/resources?tag=${tag.toLowerCase().replace(/\s+/g, '-')}`}
                      className="bg-white text-gray-700 px-3 py-1 rounded-full text-sm hover:bg-primary hover:text-white transition-colors duration-300"
                      data-testid={`link-tag-${tag.toLowerCase().replace(/\s+/g, '-')}`}
                    >
                      {tag}
                    </Link>
                  ))}
                </div>
              </div>
            </div>
          </div>

          {/* Recently Added Categories */}
          <div className="mt-16">
            <div className="text-center mb-12">
              <h2 className="text-3xl font-bold text-deep-gray mb-4">Recently Added</h2>
              <p className="text-xl text-gray-600">New resources and categories we've recently added</p>
            </div>
            <div className="grid md:grid-cols-3 gap-6">
              {[
                {
                  title: "Technology Tools",
                  description: "Apps and digital tools to support autism",
                  count: "15 new resources",
                  isNew: true,
                },
                {
                  title: "Adult Transition Planning",
                  description: "Resources for transitioning to adulthood",
                  count: "25 new resources",
                  isNew: true,
                },
                {
                  title: "Cultural Considerations",
                  description: "Autism support across different cultures",
                  count: "10 new resources",
                  isNew: true,
                },
              ].map((item, index) => (
                <div 
                  key={index}
                  className="bg-white rounded-xl p-6 shadow-lg hover-lift border-l-4 border-accent"
                >
                  <div className="flex items-center justify-between mb-3">
                    <h3 className="font-semibold text-deep-gray">{item.title}</h3>
                    {item.isNew && (
                      <span className="bg-accent text-white px-2 py-1 rounded-full text-xs font-medium">
                        New
                      </span>
                    )}
                  </div>
                  <p className="text-gray-600 text-sm mb-3">{item.description}</p>
                  <p className="text-primary text-sm font-medium">{item.count}</p>
                </div>
              ))}
            </div>
          </div>

          {/* CTA Section */}
          <div className="mt-16 text-center">
            <div className="bg-gradient-to-r from-primary to-secondary rounded-2xl p-12">
              <h2 className="text-3xl font-bold text-white mb-4">Can't Find What You're Looking For?</h2>
              <p className="text-white/90 mb-8 text-lg">
                Our team is constantly adding new resources. Let us know what you need and we'll prioritize it.
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <Button 
                  className="bg-white text-primary hover:bg-gray-100 px-8 py-3"
                  data-testid="button-suggest-resource"
                >
                  Suggest a Resource
                </Button>
                <Button 
                  variant="outline"
                  className="border-white text-white hover:bg-white hover:text-primary px-8 py-3"
                  data-testid="button-contact-team"
                >
                  Contact Our Team
                </Button>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
