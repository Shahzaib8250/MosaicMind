import { Button } from "@/components/ui/button";
import { GlassCard } from "@/components/ui/glass-card";
import { TestimonialCard } from "@/components/ui/testimonial-card";
import { 
  Star, 
  Apple, 
  Play, 
  Smartphone, 
  Cloud, 
  Lock,
  Download,
  Users,
  Trophy
} from "lucide-react";

export default function App() {
  const features = [
    {
      icon: Smartphone,
      title: "Cross-Platform Access",
      description: "Available on iOS, Android, and web browsers for seamless access anywhere.",
    },
    {
      icon: Cloud,
      title: "Cloud Sync",
      description: "Your data is automatically backed up and synced across all your devices.",
    },
    {
      icon: Lock,
      title: "Secure & Private",
      description: "Bank-level encryption ensures your family's data remains safe and private.",
    },
  ];

  const pricingPlans = [
    {
      name: "Free",
      price: "$0",
      period: "forever",
      features: [
        "Basic progress tracking",
        "Access to 50+ resources",
        "Community forums",
        "Mobile app access",
      ],
      buttonText: "Get Started",
      popular: false,
    },
    {
      name: "Premium",
      price: "$9.99",
      period: "per month",
      features: [
        "Advanced progress tracking",
        "Access to 500+ resources",
        "1-on-1 expert consultations",
        "Priority community support",
        "Personalized recommendations",
        "Advanced analytics",
      ],
      buttonText: "Start Free Trial",
      popular: true,
    },
    {
      name: "Family",
      price: "$19.99",
      period: "per month",
      features: [
        "Everything in Premium",
        "Support for multiple children",
        "Family collaboration tools",
        "Care team coordination",
        "Advanced reporting",
        "24/7 priority support",
      ],
      buttonText: "Contact Sales",
      popular: false,
    },
  ];

  const reviews = [
    {
      name: "Jennifer K.",
      role: "Parent of twins with autism",
      content: "The app has revolutionized how we track our children's progress. The visual reports are incredibly helpful for IEP meetings.",
      rating: 5,
      imageUrl: "https://images.unsplash.com/photo-1494790108755-2616b612b47c?ixlib=rb-4.0.3&w=100&h=100&fit=crop",
    },
    {
      name: "Dr. Robert Chen",
      role: "Developmental Pediatrician",
      content: "I recommend this app to all my patients' families. The data collection features help me provide better clinical care.",
      rating: 5,
      imageUrl: "https://images.unsplash.com/photo-1612349317150-e413f6a5b16d?ixlib=rb-4.0.3&w=100&h=100&fit=crop",
    },
    {
      name: "Lisa M.",
      role: "Special Education Teacher",
      content: "The educational resources are top-notch. I use them in my classroom and recommend them to parents regularly.",
      rating: 5,
      imageUrl: "https://images.unsplash.com/photo-1580489944761-15a19d654956?ixlib=rb-4.0.3&w=100&h=100&fit=crop",
    },
  ];

  return (
    <div className="pt-16">
      {/* Hero Section */}
      <section className="py-20 bg-gradient-to-br from-primary/10 via-secondary/5 to-transparent">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div>
              <h1 className="text-4xl md:text-5xl font-bold text-deep-gray mb-6">
                The AutismConnect App
              </h1>
              <p className="text-xl text-gray-600 mb-8 leading-relaxed">
                Transform your autism support journey with our comprehensive mobile app. Track progress, access resources, and connect with your community - all in your pocket.
              </p>
              <div className="flex flex-col sm:flex-row gap-4 mb-8">
                <Button 
                  className="bg-gradient-to-r from-primary to-primary-light text-white px-8 py-4 h-auto text-lg font-medium hover-lift"
                  data-testid="button-download-ios"
                >
                  <Apple className="w-5 h-5 mr-2" />
                  Download for iOS
                </Button>
                <Button 
                  className="bg-gradient-to-r from-secondary to-accent text-white px-8 py-4 h-auto text-lg font-medium hover-lift"
                  data-testid="button-download-android"
                >
                  <Play className="w-5 h-5 mr-2" />
                  Download for Android
                </Button>
              </div>
              <div className="flex items-center space-x-6 text-sm text-gray-600">
                <div className="flex items-center">
                  <Star className="w-5 h-5 text-yellow-400 fill-current mr-1" />
                  <span className="font-semibold">4.8</span>
                  <span className="ml-1">App Store</span>
                </div>
                <div className="flex items-center">
                  <Download className="w-5 h-5 text-primary mr-1" />
                  <span>50K+ Downloads</span>
                </div>
                <div className="flex items-center">
                  <Users className="w-5 h-5 text-secondary mr-1" />
                  <span>10K+ Families</span>
                </div>
              </div>
            </div>
            <div className="relative">
              <div className="relative mx-auto w-80 h-96 bg-gradient-to-br from-gray-800 to-gray-900 rounded-3xl p-2 shadow-2xl animate-float">
                <div className="w-full h-full bg-white rounded-2xl overflow-hidden">
                  <img 
                    src="https://images.unsplash.com/photo-1559757148-5c350d0d3c56?ixlib=rb-4.0.3&w=800&h=1000&fit=crop" 
                    alt="AutismConnect App Interface" 
                    className="w-full h-full object-cover" 
                  />
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* App Features */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-deep-gray mb-4">Why Choose Our App?</h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Built specifically for families, caregivers, and professionals supporting individuals with autism.
            </p>
          </div>
          
          <div className="grid md:grid-cols-3 gap-8">
            {features.map((feature, index) => (
              <GlassCard key={index} className="text-center">
                <feature.icon className="w-16 h-16 text-primary mx-auto mb-6" />
                <h3 className="text-xl font-semibold text-deep-gray mb-4">{feature.title}</h3>
                <p className="text-gray-600">{feature.description}</p>
              </GlassCard>
            ))}
          </div>
        </div>
      </section>

      {/* Screenshots Showcase */}
      <section className="py-20 bg-gradient-to-br from-warm-gray to-soft-gray">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-deep-gray mb-4">App Screenshots</h2>
            <p className="text-xl text-gray-600">See the app in action</p>
          </div>
          
          <div className="grid md:grid-cols-3 gap-8">
            {[
              {
                title: "Progress Dashboard",
                image: "https://images.unsplash.com/photo-1551288049-bebda4e38f71?ixlib=rb-4.0.3&w=400&h=600&fit=crop",
              },
              {
                title: "Resource Library",
                image: "https://images.unsplash.com/photo-1481627834876-b7833e8f5570?ixlib=rb-4.0.3&w=400&h=600&fit=crop",
              },
              {
                title: "Community Forums",
                image: "https://images.unsplash.com/photo-1522202176988-66273c2fd55f?ixlib=rb-4.0.3&w=400&h=600&fit=crop",
              },
            ].map((screenshot, index) => (
              <div key={index} className="bg-white rounded-2xl p-4 shadow-lg hover-lift">
                <img 
                  src={screenshot.image}
                  alt={screenshot.title}
                  className="w-full h-80 object-cover rounded-xl mb-4" 
                />
                <h3 className="text-lg font-semibold text-deep-gray text-center">{screenshot.title}</h3>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Pricing Plans */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-deep-gray mb-4">Choose Your Plan</h2>
            <p className="text-xl text-gray-600">Start free, upgrade when you're ready</p>
          </div>
          
          <div className="grid md:grid-cols-3 gap-8">
            {pricingPlans.map((plan, index) => (
              <div 
                key={index}
                className={`bg-white rounded-2xl p-8 shadow-lg hover-lift relative ${
                  plan.popular ? 'border-2 border-primary' : 'border border-gray-200'
                }`}
              >
                {plan.popular && (
                  <div className="absolute -top-4 left-1/2 transform -translate-x-1/2">
                    <span className="bg-primary text-white px-4 py-2 rounded-full text-sm font-medium flex items-center">
                      <Trophy className="w-4 h-4 mr-1" />
                      Most Popular
                    </span>
                  </div>
                )}
                <div className="text-center mb-8">
                  <h3 className="text-2xl font-bold text-deep-gray mb-2">{plan.name}</h3>
                  <div className="mb-4">
                    <span className="text-4xl font-bold text-primary">{plan.price}</span>
                    <span className="text-gray-600 ml-2">/{plan.period}</span>
                  </div>
                </div>
                <ul className="space-y-3 mb-8">
                  {plan.features.map((feature, featureIndex) => (
                    <li key={featureIndex} className="flex items-center text-gray-600">
                      <div className="w-2 h-2 bg-green-500 rounded-full mr-3"></div>
                      {feature}
                    </li>
                  ))}
                </ul>
                <Button 
                  className={`w-full ${
                    plan.popular 
                      ? 'bg-primary text-white hover:bg-primary/90' 
                      : 'bg-gray-100 text-deep-gray hover:bg-gray-200'
                  }`}
                  data-testid={`button-plan-${plan.name.toLowerCase()}`}
                >
                  {plan.buttonText}
                </Button>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* User Reviews */}
      <section className="py-20 bg-gradient-to-br from-warm-gray to-soft-gray">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-deep-gray mb-4">What Users Are Saying</h2>
            <p className="text-xl text-gray-600">Real reviews from our app users</p>
          </div>
          
          <div className="grid md:grid-cols-3 gap-8">
            {reviews.map((review, index) => (
              <TestimonialCard
                key={index}
                name={review.name}
                role={review.role}
                content={review.content}
                rating={review.rating}
                imageUrl={review.imageUrl}
              />
            ))}
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <section className="py-20 bg-white">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-deep-gray mb-4">Frequently Asked Questions</h2>
            <p className="text-xl text-gray-600">Common questions about the AutismConnect app</p>
          </div>
          
          <div className="space-y-6">
            {[
              {
                question: "Is the app really free to start?",
                answer: "Yes! Our basic plan is completely free and includes essential features like progress tracking, access to 50+ resources, and community forums.",
              },
              {
                question: "How secure is my family's data?",
                answer: "We use bank-level encryption and are HIPAA compliant. Your data is encrypted both in transit and at rest, and we never share personal information with third parties.",
              },
              {
                question: "Can I use the app offline?",
                answer: "Many features work offline, including progress tracking and saved resources. Data syncs automatically when you reconnect to the internet.",
              },
              {
                question: "Is there a web version available?",
                answer: "Yes! You can access AutismConnect through any web browser at app.autismconnect.com, with full sync across all your devices.",
              },
            ].map((faq, index) => (
              <div key={index} className="bg-gray-50 rounded-xl p-6">
                <h3 className="text-lg font-semibold text-deep-gray mb-3">{faq.question}</h3>
                <p className="text-gray-600">{faq.answer}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Final CTA */}
      <section className="py-20 bg-gradient-to-r from-primary to-secondary">
        <div className="max-w-4xl mx-auto text-center px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl md:text-4xl font-bold text-white mb-6">
            Ready to Get Started?
          </h2>
          <p className="text-xl text-white/90 mb-8">
            Join thousands of families already using AutismConnect to support their autism journey.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button 
              className="bg-white text-primary px-8 py-4 h-auto text-lg font-medium hover-lift"
              data-testid="button-final-download-ios"
            >
              <Apple className="w-5 h-5 mr-2" />
              Download for iOS
            </Button>
            <Button 
              className="bg-white text-primary px-8 py-4 h-auto text-lg font-medium hover-lift"
              data-testid="button-final-download-android"
            >
              <Play className="w-5 h-5 mr-2" />
              Download for Android
            </Button>
          </div>
        </div>
      </section>
    </div>
  );
}
