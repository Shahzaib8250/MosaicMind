import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { GlassCard } from "@/components/ui/glass-card";
import { 
  Users, 
  MessageCircle, 
  Heart, 
  MapPin,
  Globe,
  Calendar,
  Plus,
  Search,
  Shield,
  CheckCircle,
  Clock
} from "lucide-react";

export default function Community() {
  const { data: supportGroups = [], isLoading } = useQuery({
    queryKey: ["/api/support-groups"],
  });

  // Sample support groups for demonstration
  const sampleGroups = [
    {
      id: "1",
      name: "New Parents Support",
      description: "Connect with other families navigating their first steps in the autism journey.",
      category: "New Parents",
      location: "Online",
      memberCount: 142,
      isOnline: true,
    },
    {
      id: "2", 
      name: "School-Age Support",
      description: "Share experiences and strategies for school-age children with autism.",
      category: "School Age",
      location: "New York, NY",
      memberCount: 287,
      isOnline: false,
    },
    {
      id: "3",
      name: "Siblings & Family",
      description: "Resources and support for siblings and extended family members.",
      category: "Family",
      location: "Online",
      memberCount: 95,
      isOnline: true,
    },
    {
      id: "4",
      name: "Teen Transition Support",
      description: "Helping teenagers with autism navigate high school and prepare for adulthood.",
      category: "Teens",
      location: "Los Angeles, CA",
      memberCount: 156,
      isOnline: false,
    },
    {
      id: "5",
      name: "Working Parents Network",
      description: "Balancing career and caring for a child with autism.",
      category: "Working Parents",
      location: "Online",
      memberCount: 203,
      isOnline: true,
    },
    {
      id: "6",
      name: "Adults with Autism",
      description: "Self-advocacy and support for adults on the autism spectrum.",
      category: "Adults",
      location: "Chicago, IL", 
      memberCount: 89,
      isOnline: false,
    }
  ];

  const groupsToDisplay = supportGroups.length > 0 ? supportGroups : sampleGroups;

  const discussions = [
    {
      id: "1",
      user: {
        name: "Sarah M.",
        role: "Parent",
        avatar: "https://images.unsplash.com/photo-1494790108755-2616b612b47c?ixlib=rb-4.0.3&w=50&h=50&fit=crop",
        badge: "New Parents"
      },
      title: "Tips for sensory-friendly bedtime routines?",
      content: "My 5-year-old has been having trouble with bedtime. Looking for strategies that have worked for other families...",
      replies: 8,
      likes: 12,
      timeAgo: "2 hours ago"
    },
    {
      id: "2",
      user: {
        name: "Dr. James L.",
        role: "Professional",
        avatar: "https://images.unsplash.com/photo-1582750433449-648ed127bb54?ixlib=rb-4.0.3&w=50&h=50&fit=crop",
        badge: "Professional"
      },
      title: "Weekly Q&A: Communication Development",
      content: "Join me for this week's Q&A session focused on communication development strategies. Feel free to ask questions...",
      replies: 23,
      likes: 45,
      timeAgo: "4 hours ago"
    },
    {
      id: "3",
      user: {
        name: "Maria R.",
        role: "Parent",
        avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-4.0.3&w=50&h=50&fit=crop",
        badge: "Success Story"
      },
      title: "Celebrating my son's first independent grocery trip!",
      content: "After months of practice using the visual schedule from the app, my 12-year-old successfully completed his first solo grocery run...",
      replies: 15,
      likes: 67,
      timeAgo: "6 hours ago"
    }
  ];

  const getBadgeColor = (badge: string) => {
    const colors: Record<string, string> = {
      "New Parents": "bg-primary/10 text-primary",
      "Professional": "bg-green-100 text-green-700",
      "Success Story": "bg-secondary/10 text-secondary",
      "Family": "bg-purple-100 text-purple-700",
    };
    return colors[badge] || "bg-gray-100 text-gray-700";
  };

  return (
    <div className="pt-16">
      <section className="py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h1 className="text-4xl md:text-5xl font-bold text-deep-gray mb-6">Community Support</h1>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Connect with families, share experiences, and find support in our caring community
            </p>
          </div>

          {/* Community Stats */}
          <div className="grid md:grid-cols-4 gap-6 mb-16">
            {[
              { icon: Users, label: "Active Members", value: "12,500+" },
              { icon: MessageCircle, label: "Discussions", value: "4,200+" },
              { icon: Heart, label: "Success Stories", value: "850+" },
              { icon: Globe, label: "Support Groups", value: "75+" }
            ].map((stat, index) => (
              <GlassCard key={index} className="text-center">
                <stat.icon className="w-12 h-12 text-primary mx-auto mb-4" />
                <div className="text-2xl font-bold text-deep-gray mb-2">{stat.value}</div>
                <div className="text-gray-600">{stat.label}</div>
              </GlassCard>
            ))}
          </div>

          {/* Support Groups */}
          <div className="mb-16">
            <div className="flex justify-between items-center mb-8">
              <h2 className="text-3xl font-bold text-deep-gray">Support Groups</h2>
              <Button 
                className="bg-primary text-white hover:bg-primary/90"
                data-testid="button-create-group"
              >
                <Plus className="w-4 h-4 mr-2" />
                Create Group
              </Button>
            </div>
            
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              {groupsToDisplay.map((group: any) => (
                <div key={group.id} className="bg-white rounded-xl shadow-lg p-6 hover-lift">
                  <div className="flex items-center mb-4">
                    <div className="w-12 h-12 bg-gradient-to-r from-primary to-secondary rounded-full flex items-center justify-center mr-4">
                      <Users className="text-white w-6 h-6" />
                    </div>
                    <div>
                      <h3 className="font-semibold text-deep-gray">{group.name}</h3>
                      <div className="flex items-center text-sm text-gray-600">
                        {group.isOnline ? (
                          <Globe className="w-4 h-4 mr-1" />
                        ) : (
                          <MapPin className="w-4 h-4 mr-1" />
                        )}
                        {group.location}
                      </div>
                    </div>
                  </div>
                  <p className="text-gray-600 mb-4">{group.description}</p>
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-gray-500">{group.memberCount} members</span>
                    <Button 
                      size="sm"
                      className="bg-primary text-white hover:bg-primary/90"
                      data-testid={`button-join-group-${group.id}`}
                    >
                      Join Group
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Recent Discussions */}
          <div className="mb-16">
            <div className="flex justify-between items-center mb-8">
              <h2 className="text-3xl font-bold text-deep-gray">Recent Discussions</h2>
              <div className="flex gap-4">
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                  <Input 
                    placeholder="Search discussions..." 
                    className="pl-10 w-64"
                    data-testid="input-search-discussions"
                  />
                </div>
                <Button 
                  className="bg-secondary text-white hover:bg-secondary/90"
                  data-testid="button-new-discussion"
                >
                  <Plus className="w-4 h-4 mr-2" />
                  New Discussion
                </Button>
              </div>
            </div>
            
            <div className="bg-white rounded-xl shadow-lg overflow-hidden">
              {discussions.map((discussion, index) => (
                <div key={discussion.id} className={`p-6 ${index < discussions.length - 1 ? 'border-b border-gray-100' : ''}`}>
                  <div className="flex items-start space-x-4">
                    <img 
                      src={discussion.user.avatar}
                      alt={discussion.user.name}
                      className="w-12 h-12 rounded-full object-cover" 
                    />
                    <div className="flex-1">
                      <div className="flex items-center space-x-2 mb-2">
                        <h4 className="font-semibold text-deep-gray">{discussion.user.name}</h4>
                        {discussion.user.role === "Professional" && (
                          <CheckCircle className="w-4 h-4 text-green-500" />
                        )}
                        <span className={`px-2 py-1 rounded-full text-xs ${getBadgeColor(discussion.user.badge)}`}>
                          {discussion.user.badge}
                        </span>
                        <span className="text-sm text-gray-500 flex items-center">
                          <Clock className="w-3 h-3 mr-1" />
                          {discussion.timeAgo}
                        </span>
                      </div>
                      <h3 className="text-lg font-medium text-deep-gray mb-2">{discussion.title}</h3>
                      <p className="text-gray-600 mb-3">{discussion.content}</p>
                      <div className="flex items-center space-x-4 text-sm text-gray-500">
                        <button 
                          className="flex items-center hover:text-primary transition-colors duration-300"
                          data-testid={`button-reply-${discussion.id}`}
                        >
                          <MessageCircle className="w-4 h-4 mr-1" />
                          {discussion.replies} replies
                        </button>
                        <button 
                          className="flex items-center hover:text-red-500 transition-colors duration-300"
                          data-testid={`button-like-${discussion.id}`}
                        >
                          <Heart className="w-4 h-4 mr-1" />
                          {discussion.likes} helpful
                        </button>
                        <Button 
                          variant="link" 
                          className="text-primary hover:underline font-medium p-0"
                          data-testid={`button-view-discussion-${discussion.id}`}
                        >
                          View Discussion
                        </Button>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Community Guidelines */}
          <div className="grid md:grid-cols-2 gap-8 mb-16">
            <GlassCard>
              <h2 className="text-2xl font-bold text-deep-gray mb-6 flex items-center">
                <Shield className="w-8 h-8 text-primary mr-3" />
                Community Guidelines
              </h2>
              <div className="space-y-4">
                <div>
                  <h3 className="font-semibold text-deep-gray mb-2">Respectful Communication</h3>
                  <p className="text-gray-600 text-sm">
                    Treat all members with kindness and understanding. We're all learning together.
                  </p>
                </div>
                <div>
                  <h3 className="font-semibold text-deep-gray mb-2">Privacy Protection</h3>
                  <p className="text-gray-600 text-sm">
                    Respect privacy by not sharing personal information about yourself or others.
                  </p>
                </div>
                <div>
                  <h3 className="font-semibold text-deep-gray mb-2">Professional Guidance</h3>
                  <p className="text-gray-600 text-sm">
                    Our discussions are moderated by licensed professionals to ensure accuracy.
                  </p>
                </div>
                <div>
                  <h3 className="font-semibold text-deep-gray mb-2">Safe Space</h3>
                  <p className="text-gray-600 text-sm">
                    This is a judgment-free zone where all experiences and perspectives are valued.
                  </p>
                </div>
              </div>
            </GlassCard>

            <GlassCard>
              <h2 className="text-2xl font-bold text-deep-gray mb-6">Share Your Story</h2>
              <p className="text-gray-600 mb-6">
                Have a success story or helpful tip to share? Your experience could help another family on their journey.
              </p>
              <div className="space-y-4">
                <Input 
                  placeholder="Story title"
                  data-testid="input-story-title"
                />
                <Textarea 
                  placeholder="Share your story or tip..."
                  rows={4}
                  data-testid="textarea-story-content"
                />
                <Button 
                  className="w-full bg-primary text-white hover:bg-primary/90"
                  data-testid="button-share-story"
                >
                  Share Story
                </Button>
              </div>
            </GlassCard>
          </div>

          {/* Upcoming Events */}
          <div className="mb-16">
            <h2 className="text-3xl font-bold text-deep-gray mb-8">Upcoming Community Events</h2>
            <div className="grid md:grid-cols-3 gap-6">
              {[
                {
                  title: "Virtual Coffee Chat",
                  date: "March 20, 2024",
                  time: "7:00 PM EST",
                  type: "Online",
                  description: "Casual conversation with other parents"
                },
                {
                  title: "IEP Workshop",
                  date: "March 25, 2024", 
                  time: "2:00 PM EST",
                  type: "Webinar",
                  description: "Expert-led session on IEP preparation"
                },
                {
                  title: "Family Fun Day",
                  date: "April 1, 2024",
                  time: "10:00 AM EST",
                  type: "In-Person",
                  description: "Sensory-friendly activities for families"
                }
              ].map((event, index) => (
                <div key={index} className="bg-white rounded-xl p-6 shadow-lg hover-lift border-l-4 border-secondary">
                  <h3 className="font-semibold text-deep-gray mb-2">{event.title}</h3>
                  <div className="flex items-center text-sm text-gray-600 mb-2">
                    <Calendar className="w-4 h-4 mr-2" />
                    {event.date} at {event.time}
                  </div>
                  <div className="flex items-center text-sm text-gray-600 mb-3">
                    {event.type === "Online" ? (
                      <Globe className="w-4 h-4 mr-2" />
                    ) : (
                      <MapPin className="w-4 h-4 mr-2" />
                    )}
                    {event.type}
                  </div>
                  <p className="text-gray-600 text-sm mb-4">{event.description}</p>
                  <Button 
                    size="sm"
                    className="w-full bg-secondary text-white hover:bg-secondary/90"
                    data-testid={`button-register-event-${index}`}
                  >
                    Register
                  </Button>
                </div>
              ))}
            </div>
          </div>

          {/* CTA Section */}
          <div className="text-center">
            <div className="bg-gradient-to-r from-primary to-secondary rounded-2xl p-12">
              <h2 className="text-3xl font-bold text-white mb-4">Ready to Join Our Community?</h2>
              <p className="text-white/90 mb-8 text-lg">
                Connect with thousands of families and professionals who understand your journey.
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <Button 
                  className="bg-white text-primary hover:bg-gray-100 px-8 py-3"
                  data-testid="button-join-community"
                >
                  Join the Community
                </Button>
                <Button 
                  variant="outline"
                  className="border-white text-white hover:bg-white hover:text-primary px-8 py-3"
                  data-testid="button-browse-groups"
                >
                  Browse Groups
                </Button>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
