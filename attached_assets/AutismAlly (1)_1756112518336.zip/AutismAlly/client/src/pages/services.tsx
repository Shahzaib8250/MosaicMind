import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { GlassCard } from "@/components/ui/glass-card";
import { TestimonialCard } from "@/components/ui/testimonial-card";
import { 
  UserCheck, 
  GraduationCap, 
  Users, 
  Calendar,
  Clock,
  Video,
  MapPin,
  Star,
  CheckCircle,
  Phone,
  Mail
} from "lucide-react";
import { useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

export default function Services() {
  const [selectedService, setSelectedService] = useState("");
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    phone: "",
    service: "",
    childAge: "",
    preferredDate: "",
    preferredTime: "",
    message: ""
  });

  const { toast } = useToast();

  const contactMutation = useMutation({
    mutationFn: (data: any) => apiRequest("POST", "/api/contact", data),
    onSuccess: () => {
      toast({
        title: "Booking request sent!",
        description: "We'll contact you within 24 hours to confirm your appointment.",
      });
      setFormData({
        name: "",
        email: "",
        phone: "",
        service: "",
        childAge: "",
        preferredDate: "",
        preferredTime: "",
        message: ""
      });
    },
    onError: () => {
      toast({
        title: "Booking failed",
        description: "Please try again or contact us directly.",
        variant: "destructive",
      });
    },
  });

  const services = [
    {
      id: "consultation",
      icon: UserCheck,
      title: "Individual Consultation",
      duration: "60 minutes",
      price: "$150",
      format: "In-person or Virtual",
      description: "One-on-one consultation with our experienced autism specialists to discuss your specific needs and develop a personalized plan.",
      features: [
        "Comprehensive assessment discussion",
        "Personalized recommendations",
        "Resource planning",
        "Follow-up support",
        "Written summary report"
      ],
      professional: "Dr. Emily Carter, Clinical Psychologist"
    },
    {
      id: "workshop",
      icon: GraduationCap,
      title: "Parent Training Workshop",
      duration: "3 hours",
      price: "$89",
      format: "Group or Virtual",
      description: "Interactive workshops covering essential strategies for supporting your child's development and managing daily challenges.",
      features: [
        "Evidence-based strategies",
        "Hands-on practice",
        "Q&A sessions",
        "Take-home materials",
        "Community connections"
      ],
      professional: "Multiple certified trainers"
    },
    {
      id: "therapy",
      icon: Users,
      title: "Family Therapy Session",
      duration: "90 minutes",
      price: "$200",
      format: "In-person preferred",
      description: "Family-focused therapy sessions designed to improve communication, reduce stress, and strengthen family bonds.",
      features: [
        "Whole family approach",
        "Communication strategies",
        "Stress management",
        "Sibling support",
        "Goal setting"
      ],
      professional: "Dr. Sarah Johnson, Family Therapist"
    },
    {
      id: "assessment",
      icon: CheckCircle,
      title: "Comprehensive Assessment",
      duration: "2-3 hours",
      price: "$350",
      format: "In-person required",
      description: "Thorough developmental and behavioral assessment to better understand your child's strengths and needs.",
      features: [
        "Standardized assessments",
        "Behavioral observations",
        "Detailed report",
        "Recommendations",
        "Resource referrals"
      ],
      professional: "Dr. Michael Rodriguez, Developmental Pediatrician"
    },
    {
      id: "support",
      icon: Calendar,
      title: "Ongoing Support Plan",
      duration: "Monthly sessions",
      price: "$120/month",
      format: "Flexible",
      description: "Regular check-ins and support to help you implement strategies and track progress over time.",
      features: [
        "Monthly consultations",
        "Progress tracking",
        "Strategy adjustments",
        "Crisis support",
        "Resource updates"
      ],
      professional: "Assigned care coordinator"
    },
    {
      id: "webinar",
      icon: Video,
      title: "Educational Webinar Series",
      duration: "1 hour each",
      price: "$29/webinar",
      format: "Online only",
      description: "Monthly educational webinars covering various autism-related topics led by experts in the field.",
      features: [
        "Expert presentations",
        "Live Q&A",
        "Recording access",
        "Handouts included",
        "Certificate of attendance"
      ],
      professional: "Various guest experts"
    }
  ];

  const testimonials = [
    {
      name: "Jennifer K.",
      role: "Parent of 8-year-old",
      content: "The consultation with Dr. Carter completely changed our approach. Her insights and practical strategies have made such a difference in our daily routine.",
      rating: 5,
      imageUrl: "https://images.unsplash.com/photo-1494790108755-2616b612b47c?ixlib=rb-4.0.3&w=100&h=100&fit=crop"
    },
    {
      name: "Mark and Lisa T.",
      role: "Parents of twin boys",
      content: "The family therapy sessions helped us communicate better as a family and gave us tools to support both our boys effectively.",
      rating: 5,
      imageUrl: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-4.0.3&w=100&h=100&fit=crop"
    },
    {
      name: "Dr. Patricia M.",
      role: "School Psychologist",
      content: "I regularly recommend the workshops to families. The practical strategies and supportive environment are exactly what parents need.",
      rating: 5,
      imageUrl: "https://images.unsplash.com/photo-1580489944761-15a19d654956?ixlib=rb-4.0.3&w=100&h=100&fit=crop"
    }
  ];

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    contactMutation.mutate({
      ...formData,
      subject: `Booking Request: ${formData.service}`,
      message: `Service: ${formData.service}\nChild Age: ${formData.childAge}\nPreferred Date: ${formData.preferredDate}\nPreferred Time: ${formData.preferredTime}\n\nMessage: ${formData.message}`
    });
  };

  return (
    <div className="pt-16">
      <section className="py-20 bg-gradient-to-br from-warm-gray to-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h1 className="text-4xl md:text-5xl font-bold text-deep-gray mb-6">Professional Services</h1>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Expert consultation, training, and therapy services to support your family's autism journey
            </p>
          </div>

          {/* Service Categories */}
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8 mb-16">
            {services.map((service) => (
              <Card key={service.id} className="hover-lift cursor-pointer transition-all duration-300 border-0 shadow-lg">
                <CardHeader className="text-center pb-4">
                  <div className={`w-16 h-16 bg-gradient-to-r from-primary to-secondary rounded-2xl flex items-center justify-center mx-auto mb-4`}>
                    <service.icon className="text-white w-8 h-8" />
                  </div>
                  <CardTitle className="text-xl font-semibold text-deep-gray">{service.title}</CardTitle>
                  <div className="flex items-center justify-center space-x-4 text-sm text-gray-600">
                    <div className="flex items-center">
                      <Clock className="w-4 h-4 mr-1" />
                      {service.duration}
                    </div>
                    <div className="text-primary font-semibold">{service.price}</div>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="flex items-center justify-center mb-4">
                    <span className="bg-gray-100 text-gray-700 px-3 py-1 rounded-full text-sm">
                      {service.format}
                    </span>
                  </div>
                  <p className="text-gray-600 mb-4 text-center">{service.description}</p>
                  <ul className="space-y-2 mb-6">
                    {service.features.map((feature, index) => (
                      <li key={index} className="flex items-center text-sm text-gray-600">
                        <CheckCircle className="w-4 h-4 text-green-500 mr-2 flex-shrink-0" />
                        {feature}
                      </li>
                    ))}
                  </ul>
                  <div className="text-center">
                    <p className="text-xs text-gray-500 mb-3">Led by: {service.professional}</p>
                    <Button 
                      onClick={() => setSelectedService(service.title)}
                      className="w-full bg-primary text-white hover:bg-primary/90"
                      data-testid={`button-book-${service.id}`}
                    >
                      Book {service.title}
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          {/* Booking Form */}
          <div className="grid lg:grid-cols-2 gap-12 mb-16">
            <GlassCard>
              <h2 className="text-2xl font-bold text-deep-gray mb-6">Book a Service</h2>
              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="grid md:grid-cols-2 gap-4">
                  <Input
                    placeholder="Your Name"
                    value={formData.name}
                    onChange={(e) => setFormData({...formData, name: e.target.value})}
                    data-testid="input-booking-name"
                    required
                  />
                  <Input
                    type="email"
                    placeholder="Email Address"
                    value={formData.email}
                    onChange={(e) => setFormData({...formData, email: e.target.value})}
                    data-testid="input-booking-email"
                    required
                  />
                </div>
                <div className="grid md:grid-cols-2 gap-4">
                  <Input
                    type="tel"
                    placeholder="Phone Number"
                    value={formData.phone}
                    onChange={(e) => setFormData({...formData, phone: e.target.value})}
                    data-testid="input-booking-phone"
                    required
                  />
                  <Select value={formData.service} onValueChange={(value) => setFormData({...formData, service: value})}>
                    <SelectTrigger data-testid="select-service">
                      <SelectValue placeholder={selectedService || "Select Service"} />
                    </SelectTrigger>
                    <SelectContent>
                      {services.map((service) => (
                        <SelectItem key={service.id} value={service.title}>
                          {service.title}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="grid md:grid-cols-3 gap-4">
                  <Input
                    placeholder="Child's Age"
                    value={formData.childAge}
                    onChange={(e) => setFormData({...formData, childAge: e.target.value})}
                    data-testid="input-child-age"
                  />
                  <Input
                    type="date"
                    placeholder="Preferred Date"
                    value={formData.preferredDate}
                    onChange={(e) => setFormData({...formData, preferredDate: e.target.value})}
                    data-testid="input-preferred-date"
                  />
                  <Select value={formData.preferredTime} onValueChange={(value) => setFormData({...formData, preferredTime: value})}>
                    <SelectTrigger data-testid="select-preferred-time">
                      <SelectValue placeholder="Preferred Time" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="morning">Morning (9 AM - 12 PM)</SelectItem>
                      <SelectItem value="afternoon">Afternoon (12 PM - 5 PM)</SelectItem>
                      <SelectItem value="evening">Evening (5 PM - 8 PM)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <Textarea
                  placeholder="Tell us about your specific needs or questions..."
                  rows={4}
                  value={formData.message}
                  onChange={(e) => setFormData({...formData, message: e.target.value})}
                  data-testid="textarea-booking-message"
                />
                <Button 
                  type="submit"
                  className="w-full bg-primary text-white hover:bg-primary/90"
                  disabled={contactMutation.isPending}
                  data-testid="button-submit-booking"
                >
                  {contactMutation.isPending ? "Sending..." : "Book Appointment"}
                </Button>
              </form>
            </GlassCard>

            <div className="space-y-6">
              <GlassCard>
                <h3 className="text-xl font-bold text-deep-gray mb-4">What to Expect</h3>
                <div className="space-y-4">
                  <div className="flex items-start space-x-3">
                    <div className="w-8 h-8 bg-primary/10 rounded-full flex items-center justify-center flex-shrink-0 mt-1">
                      <span className="text-primary font-semibold text-sm">1</span>
                    </div>
                    <div>
                      <h4 className="font-medium text-deep-gray">Initial Contact</h4>
                      <p className="text-gray-600 text-sm">We'll contact you within 24 hours to confirm your appointment and discuss any preparations needed.</p>
                    </div>
                  </div>
                  <div className="flex items-start space-x-3">
                    <div className="w-8 h-8 bg-secondary/10 rounded-full flex items-center justify-center flex-shrink-0 mt-1">
                      <span className="text-secondary font-semibold text-sm">2</span>
                    </div>
                    <div>
                      <h4 className="font-medium text-deep-gray">Preparation</h4>
                      <p className="text-gray-600 text-sm">We'll send you intake forms and preparation materials to help make the most of your session.</p>
                    </div>
                  </div>
                  <div className="flex items-start space-x-3">
                    <div className="w-8 h-8 bg-accent/10 rounded-full flex items-center justify-center flex-shrink-0 mt-1">
                      <span className="text-accent font-semibold text-sm">3</span>
                    </div>
                    <div>
                      <h4 className="font-medium text-deep-gray">Your Session</h4>
                      <p className="text-gray-600 text-sm">Professional, compassionate service focused on your family's unique needs and goals.</p>
                    </div>
                  </div>
                  <div className="flex items-start space-x-3">
                    <div className="w-8 h-8 bg-green-100 rounded-full flex items-center justify-center flex-shrink-0 mt-1">
                      <span className="text-green-700 font-semibold text-sm">4</span>
                    </div>
                    <div>
                      <h4 className="font-medium text-deep-gray">Follow-up</h4>
                      <p className="text-gray-600 text-sm">Receive resources, recommendations, and ongoing support to implement what you've learned.</p>
                    </div>
                  </div>
                </div>
              </GlassCard>

              <GlassCard>
                <h3 className="text-xl font-bold text-deep-gray mb-4">Contact Information</h3>
                <div className="space-y-3">
                  <div className="flex items-center space-x-3">
                    <Phone className="w-5 h-5 text-primary" />
                    <span className="text-gray-600">(555) 123-4567</span>
                  </div>
                  <div className="flex items-center space-x-3">
                    <Mail className="w-5 h-5 text-primary" />
                    <span className="text-gray-600">services@autismconnect.com</span>
                  </div>
                  <div className="flex items-center space-x-3">
                    <MapPin className="w-5 h-5 text-primary" />
                    <span className="text-gray-600">123 Wellness Center Dr, Suite 200</span>
                  </div>
                </div>
              </GlassCard>
            </div>
          </div>

          {/* Testimonials */}
          <div className="mb-16">
            <h2 className="text-3xl font-bold text-deep-gray text-center mb-12">What Families Are Saying</h2>
            <div className="grid md:grid-cols-3 gap-8">
              {testimonials.map((testimonial, index) => (
                <TestimonialCard
                  key={index}
                  name={testimonial.name}
                  role={testimonial.role}
                  content={testimonial.content}
                  rating={testimonial.rating}
                  imageUrl={testimonial.imageUrl}
                />
              ))}
            </div>
          </div>

          {/* Insurance & Payment Info */}
          <GlassCard>
            <div className="grid md:grid-cols-2 gap-8">
              <div>
                <h3 className="text-xl font-bold text-deep-gray mb-4">Insurance & Payment</h3>
                <ul className="space-y-3 text-gray-600">
                  <li className="flex items-center">
                    <CheckCircle className="w-4 h-4 text-green-500 mr-2" />
                    Most major insurance plans accepted
                  </li>
                  <li className="flex items-center">
                    <CheckCircle className="w-4 h-4 text-green-500 mr-2" />
                    Flexible payment plans available
                  </li>
                  <li className="flex items-center">
                    <CheckCircle className="w-4 h-4 text-green-500 mr-2" />
                    HSA/FSA eligible services
                  </li>
                  <li className="flex items-center">
                    <CheckCircle className="w-4 h-4 text-green-500 mr-2" />
                    Sliding scale fees for qualifying families
                  </li>
                </ul>
              </div>
              <div>
                <h3 className="text-xl font-bold text-deep-gray mb-4">Cancellation Policy</h3>
                <ul className="space-y-3 text-gray-600">
                  <li>• 24-hour notice required for cancellations</li>
                  <li>• Emergency cancellations accepted</li>
                  <li>• Rescheduling available at no extra cost</li>
                  <li>• Late cancellation fees may apply</li>
                </ul>
              </div>
            </div>
          </GlassCard>
        </div>
      </section>
    </div>
  );
}
