import { useState } from "react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { GlassCard } from "@/components/ui/glass-card";
import { 
  Search, 
  ChevronDown, 
  ChevronUp, 
  HelpCircle, 
  Smartphone, 
  CreditCard, 
  Download, 
  Headphones,
  Mail,
  Phone,
  MessageCircle
} from "lucide-react";

export default function FAQ() {
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("All");
  const [expandedItems, setExpandedItems] = useState<string[]>([]);

  const categories = [
    { id: "All", label: "All Questions", icon: HelpCircle },
    { id: "App", label: "About the App", icon: Smartphone },
    { id: "Features", label: "App Functionality", icon: Download },
    { id: "Pricing", label: "Subscriptions & Pricing", icon: CreditCard },
    { id: "Resources", label: "Resources & Downloads", icon: Download },
    { id: "Support", label: "Technical Support", icon: Headphones },
  ];

  const faqs = [
    {
      id: "1",
      category: "App",
      question: "What is AutismConnect and how can it help my family?",
      answer: "AutismConnect is a comprehensive platform designed specifically for families affected by autism. It provides tools for progress tracking, access to educational resources, community support, and professional guidance. Our app helps you monitor your child's development, connect with other families, and access evidence-based resources all in one place."
    },
    {
      id: "2",
      category: "App",
      question: "Is AutismConnect really free to use?",
      answer: "Yes! We offer a robust free plan that includes basic progress tracking, access to 50+ resources, community forums, and mobile app access. We also offer premium plans with additional features like advanced analytics, 1-on-1 consultations, and access to our full resource library of 500+ materials."
    },
    {
      id: "3",
      category: "Features",
      question: "How does the progress tracking work?",
      answer: "Our progress tracking system allows you to log daily activities, milestones, behaviors, and therapy goals. You can add photos, videos, and notes to document your child's development. The app creates visual charts and reports that help you see patterns and progress over time, which you can share with healthcare providers and therapists."
    },
    {
      id: "4",
      category: "Features",
      question: "Can I track multiple children on one account?",
      answer: "Yes! Our Family plan allows you to create separate profiles for multiple children. Each child gets their own personalized dashboard, progress tracking, and resource recommendations. You can easily switch between profiles and compare progress across siblings."
    },
    {
      id: "5",
      category: "Features",
      question: "How secure is my family's data?",
      answer: "We take data security very seriously. All information is encrypted both in transit and at rest using bank-level security. We are HIPAA compliant and never share personal information with third parties. You have complete control over your data and can export or delete it at any time."
    },
    {
      id: "6",
      category: "Features",
      question: "Can I use the app offline?",
      answer: "Many features work offline, including progress tracking, viewing saved resources, and accessing downloaded materials. Your data automatically syncs when you reconnect to the internet. This ensures you can continue using the app even in areas with poor connectivity."
    },
    {
      id: "7",
      category: "Pricing",
      question: "What's included in the free plan?",
      answer: "The free plan includes basic progress tracking for one child, access to 50+ curated resources, participation in community forums, mobile app access, and basic milestone tracking. It's perfect for families just starting their autism journey or those who want to try our platform."
    },
    {
      id: "8",
      category: "Pricing",
      question: "What are the premium plan benefits?",
      answer: "Premium plans include advanced progress tracking, access to 500+ resources, personalized recommendations, 1-on-1 expert consultations, priority community support, advanced analytics and reporting, care team collaboration tools, and 24/7 priority support."
    },
    {
      id: "9",
      category: "Pricing",
      question: "Can I cancel my subscription anytime?",
      answer: "Absolutely! You can cancel your subscription at any time from your account settings. There are no cancellation fees, and you'll continue to have access to premium features until the end of your billing period. You can always resubscribe later if needed."
    },
    {
      id: "10",
      category: "Pricing",
      question: "Do you accept insurance or offer financial assistance?",
      answer: "While we don't directly bill insurance, many of our services may be eligible for reimbursement through HSA/FSA accounts. We also offer sliding scale pricing for qualifying families and have partnerships with several autism organizations that provide scholarships."
    },
    {
      id: "11",
      category: "Resources",
      question: "What types of resources do you provide?",
      answer: "We offer a comprehensive library including therapy guides, educational worksheets, visual supports, social stories, assessment tools, behavior charts, communication aids, sensory activities, and much more. All resources are created or reviewed by autism professionals and are evidence-based."
    },
    {
      id: "12",
      category: "Resources",
      question: "How often do you add new resources?",
      answer: "We add new resources weekly! Our team continuously works with autism professionals, researchers, and families to identify needs and create new materials. Premium subscribers get early access to new resources and can request specific types of materials."
    },
    {
      id: "13",
      category: "Resources",
      question: "Can I suggest resources or request specific materials?",
      answer: "Yes! We encourage user feedback and suggestions. You can submit resource requests through the app or by contacting our team. We regularly review suggestions and prioritize the most requested materials for development."
    },
    {
      id: "14",
      category: "Support",
      question: "How do I get technical help if I'm having issues?",
      answer: "We offer multiple support channels: in-app help center, email support (support@autismconnect.com), live chat during business hours, and phone support for premium subscribers. Our team typically responds to support requests within 4 hours during business days."
    },
    {
      id: "15",
      category: "Support",
      question: "Is there a web version of the app?",
      answer: "Yes! You can access AutismConnect through any web browser at app.autismconnect.com. All your data syncs seamlessly between the mobile app and web version, so you can use whichever is most convenient for you."
    },
    {
      id: "16",
      category: "Support",
      question: "What devices and operating systems are supported?",
      answer: "Our mobile app is available for iOS (iPhone and iPad) and Android devices. The web version works on all modern browsers including Chrome, Firefox, Safari, and Edge. We regularly update our apps to support the latest operating system versions."
    },
    {
      id: "17",
      category: "App",
      question: "How is AutismConnect different from other autism apps?",
      answer: "AutismConnect is unique because it combines progress tracking, educational resources, and community support in one comprehensive platform. Unlike other apps that focus on just one aspect, we provide a complete ecosystem backed by clinical expertise and designed specifically for the autism community."
    },
    {
      id: "18",
      category: "Features",
      question: "Can my child's therapists and teachers access the information?",
      answer: "Yes! With your permission, you can invite therapists, teachers, and other care team members to view relevant information. You control what each person can see and can revoke access at any time. This feature helps ensure everyone working with your child is aligned and informed."
    }
  ];

  const toggleExpanded = (id: string) => {
    setExpandedItems(prev => 
      prev.includes(id) 
        ? prev.filter(item => item !== id)
        : [...prev, id]
    );
  };

  const filteredFaqs = faqs.filter(faq => {
    const matchesCategory = selectedCategory === "All" || faq.category === selectedCategory;
    const matchesSearch = faq.question.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         faq.answer.toLowerCase().includes(searchTerm.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  return (
    <div className="pt-16">
      <section className="py-20 bg-gradient-to-br from-warm-gray to-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h1 className="text-4xl md:text-5xl font-bold text-deep-gray mb-6">Frequently Asked Questions</h1>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Find answers to common questions about AutismConnect, our features, and how we can support your family's journey
            </p>
          </div>

          {/* Search Bar */}
          <div className="max-w-2xl mx-auto mb-12">
            <div className="relative">
              <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
              <Input
                placeholder="Search frequently asked questions..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-12 py-4 text-lg rounded-2xl border-gray-200 focus:border-primary"
                data-testid="input-search-faq"
              />
            </div>
          </div>

          {/* Category Filters */}
          <div className="flex flex-wrap justify-center gap-4 mb-12">
            {categories.map((category) => (
              <Button
                key={category.id}
                variant={selectedCategory === category.id ? "default" : "outline"}
                onClick={() => setSelectedCategory(category.id)}
                className={`hover-lift transition-all duration-300 ${
                  selectedCategory === category.id 
                    ? 'bg-primary text-white' 
                    : 'bg-white text-gray-700 hover:bg-gray-50'
                }`}
                data-testid={`button-category-${category.id.toLowerCase()}`}
              >
                <category.icon className="w-4 h-4 mr-2" />
                {category.label}
              </Button>
            ))}
          </div>

          {/* FAQ Items */}
          <div className="max-w-4xl mx-auto mb-16">
            {filteredFaqs.length > 0 ? (
              <div className="space-y-4">
                {filteredFaqs.map((faq) => {
                  const isExpanded = expandedItems.includes(faq.id);
                  return (
                    <div key={faq.id} className="bg-white rounded-xl shadow-lg overflow-hidden hover-lift">
                      <button
                        onClick={() => toggleExpanded(faq.id)}
                        className="w-full p-6 text-left flex items-center justify-between hover:bg-gray-50 transition-colors duration-300"
                        data-testid={`button-faq-${faq.id}`}
                      >
                        <div className="flex-1">
                          <div className="flex items-center mb-2">
                            <span className="bg-primary/10 text-primary px-2 py-1 rounded-full text-xs font-medium mr-3">
                              {categories.find(cat => cat.id === faq.category)?.label}
                            </span>
                          </div>
                          <h3 className="text-lg font-semibold text-deep-gray">{faq.question}</h3>
                        </div>
                        {isExpanded ? (
                          <ChevronUp className="w-6 h-6 text-gray-400 flex-shrink-0 ml-4" />
                        ) : (
                          <ChevronDown className="w-6 h-6 text-gray-400 flex-shrink-0 ml-4" />
                        )}
                      </button>
                      {isExpanded && (
                        <div className="px-6 pb-6">
                          <div className="border-t border-gray-100 pt-4">
                            <p className="text-gray-600 leading-relaxed">{faq.answer}</p>
                          </div>
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            ) : (
              <div className="text-center py-12">
                <HelpCircle className="w-16 h-16 text-gray-300 mx-auto mb-4" />
                <p className="text-gray-600 text-lg mb-4">No questions found matching your search.</p>
                <Button 
                  onClick={() => {
                    setSearchTerm("");
                    setSelectedCategory("All");
                  }}
                  data-testid="button-clear-search"
                >
                  Clear Search
                </Button>
              </div>
            )}
          </div>

          {/* Contact Support Section */}
          <div className="grid md:grid-cols-3 gap-8 mb-16">
            <GlassCard className="text-center">
              <Mail className="w-12 h-12 text-primary mx-auto mb-4" />
              <h3 className="text-xl font-semibold text-deep-gray mb-3">Email Support</h3>
              <p className="text-gray-600 mb-4">Get detailed answers to your questions via email</p>
              <Button 
                className="bg-primary text-white hover:bg-primary/90"
                data-testid="button-email-support"
              >
                Send Email
              </Button>
            </GlassCard>

            <GlassCard className="text-center">
              <MessageCircle className="w-12 h-12 text-secondary mx-auto mb-4" />
              <h3 className="text-xl font-semibold text-deep-gray mb-3">Live Chat</h3>
              <p className="text-gray-600 mb-4">Chat with our support team in real-time</p>
              <Button 
                className="bg-secondary text-white hover:bg-secondary/90"
                data-testid="button-live-chat"
              >
                Start Chat
              </Button>
            </GlassCard>

            <GlassCard className="text-center">
              <Phone className="w-12 h-12 text-accent mx-auto mb-4" />
              <h3 className="text-xl font-semibold text-deep-gray mb-3">Phone Support</h3>
              <p className="text-gray-600 mb-4">Speak directly with our support specialists</p>
              <Button 
                className="bg-accent text-white hover:bg-accent/90"
                data-testid="button-phone-support"
              >
                Call Now
              </Button>
            </GlassCard>
          </div>

          {/* Popular Topics */}
          <div className="mb-16">
            <h2 className="text-3xl font-bold text-deep-gray text-center mb-8">Popular Help Topics</h2>
            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-4">
              {[
                "Getting Started Guide",
                "Setting Up Progress Tracking", 
                "Finding the Right Resources",
                "Connecting with Support Groups",
                "Understanding Your Dashboard",
                "Sharing Data with Providers",
                "Managing Multiple Children",
                "Troubleshooting Common Issues"
              ].map((topic, index) => (
                <Button
                  key={index}
                  variant="outline"
                  className="h-auto p-4 text-left justify-start hover:bg-primary hover:text-white transition-colors duration-300"
                  data-testid={`button-topic-${index}`}
                >
                  {topic}
                </Button>
              ))}
            </div>
          </div>

          {/* Still Need Help CTA */}
          <div className="text-center">
            <GlassCard>
              <h2 className="text-3xl font-bold text-deep-gray mb-4">Still Need Help?</h2>
              <p className="text-xl text-gray-600 mb-8 max-w-2xl mx-auto">
                Can't find the answer you're looking for? Our support team is here to help you every step of the way.
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <Button 
                  className="bg-primary text-white hover:bg-primary/90 px-8 py-3"
                  data-testid="button-contact-support"
                >
                  Contact Support
                </Button>
                <Button 
                  variant="outline"
                  className="px-8 py-3"
                  data-testid="button-schedule-call"
                >
                  Schedule a Call
                </Button>
              </div>
              <div className="mt-6 text-sm text-gray-500">
                <p>Average response time: 4 hours | Available Monday-Friday, 9 AM - 6 PM EST</p>
              </div>
            </GlassCard>
          </div>
        </div>
      </section>
    </div>
  );
}
