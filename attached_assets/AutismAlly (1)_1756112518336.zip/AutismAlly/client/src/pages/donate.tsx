import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { GlassCard } from "@/components/ui/glass-card";
import { TestimonialCard } from "@/components/ui/testimonial-card";
import { 
  Heart, 
  Users, 
  BookOpen, 
  GraduationCap,
  Stethoscope,
  Globe,
  CheckCircle,
  CreditCard,
  Calendar,
  HandHeart,
  Target,
  TrendingUp,
  Star,
  DollarSign,
  Clock
} from "lucide-react";
import { useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

export default function Donate() {
  const [donationType, setDonationType] = useState("one-time");
  const [donationAmount, setDonationAmount] = useState("50");
  const [customAmount, setCustomAmount] = useState("");
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    message: "",
    anonymous: false,
    newsletter: false
  });

  const { toast } = useToast();

  const donationMutation = useMutation({
    mutationFn: (data: any) => apiRequest("POST", "/api/contact", data),
    onSuccess: () => {
      toast({
        title: "Thank you for your donation!",
        description: "Your generous contribution will help support families in the autism community.",
      });
      setFormData({
        name: "",
        email: "",
        message: "",
        anonymous: false,
        newsletter: false
      });
    },
    onError: () => {
      toast({
        title: "Donation processing failed",
        description: "Please try again or contact our support team.",
        variant: "destructive",
      });
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const amount = donationAmount === "custom" ? customAmount : donationAmount;
    donationMutation.mutate({
      ...formData,
      subject: `Donation Request - $${amount} (${donationType})`,
      message: `Donation Type: ${donationType}\nAmount: $${amount}\nAnonymous: ${formData.anonymous}\nNewsletter: ${formData.newsletter}\n\nMessage: ${formData.message}`
    });
  };

  const impactStats = [
    {
      icon: Users,
      value: "12,500+",
      label: "Families Supported",
      description: "Direct support through our platform and resources"
    },
    {
      icon: BookOpen,
      value: "500+",
      label: "Resources Created",
      description: "Evidence-based materials developed by experts"
    },
    {
      icon: GraduationCap,
      value: "150+",
      label: "Workshops Hosted",
      description: "Educational sessions for families and professionals"
    },
    {
      icon: Stethoscope,
      value: "2,500+",
      label: "Consultations Provided",
      description: "Professional guidance and support sessions"
    }
  ];

  const donationTiers = [
    {
      amount: "25",
      title: "Community Supporter",
      description: "Provides educational resources to 5 families",
      impact: "Helps create new therapy guides and worksheets"
    },
    {
      amount: "50",
      title: "Family Advocate",
      description: "Funds one professional consultation session",
      impact: "Directly supports a family in need of expert guidance"
    },
    {
      amount: "100",
      title: "Progress Partner",
      description: "Sponsors a complete workshop for 20 families",
      impact: "Enables comprehensive training and support"
    },
    {
      amount: "250",
      title: "Community Champion",
      description: "Funds technology improvements and new features",
      impact: "Helps us reach and support more families"
    },
    {
      amount: "500",
      title: "Autism Advocate",
      description: "Sponsors research and resource development",
      impact: "Creates lasting impact through innovation"
    },
    {
      amount: "custom",
      title: "Custom Amount",
      description: "Every contribution makes a difference",
      impact: "Your generosity directly supports our mission"
    }
  ];

  const volunteerOpportunities = [
    {
      icon: Heart,
      title: "Community Moderator",
      description: "Help moderate our support groups and forums",
      time: "5-10 hours/week",
      skills: "Experience with autism, communication skills"
    },
    {
      icon: BookOpen,
      title: "Content Creator",
      description: "Develop educational resources and materials",
      time: "Flexible",
      skills: "Writing, design, or subject matter expertise"
    },
    {
      icon: Users,
      title: "Family Mentor",
      description: "Provide guidance to newly diagnosed families",
      time: "2-5 hours/week",
      skills: "Personal experience, empathy, good listener"
    },
    {
      icon: Globe,
      title: "Translation Volunteer",
      description: "Help translate resources into other languages",
      time: "Flexible",
      skills: "Bilingual proficiency, attention to detail"
    }
  ];

  const testimonials = [
    {
      name: "Maria G.",
      role: "Monthly Donor",
      content: "Knowing that my monthly contribution helps other families navigate their autism journey gives me such fulfillment. The transparency in how funds are used makes me confident in my support.",
      rating: 5,
      imageUrl: "https://images.unsplash.com/photo-1494790108755-2616b612b47c?ixlib=rb-4.0.3&w=100&h=100&fit=crop"
    },
    {
      name: "Dr. Robert K.",
      role: "Professional Donor",
      content: "As a pediatrician, I see firsthand the impact AutismConnect has on families. I'm proud to support an organization that provides such comprehensive, evidence-based resources.",
      rating: 5,
      imageUrl: "https://images.unsplash.com/photo-1612349317150-e413f6a5b16d?ixlib=rb-4.0.3&w=100&h=100&fit=crop"
    },
    {
      name: "The Johnson Family",
      role: "Grateful Recipients",
      content: "The support we received through donor-funded consultations changed our family's trajectory. We're now in a position to give back and help other families find hope.",
      rating: 5,
      imageUrl: "https://images.unsplash.com/photo-1511632765486-a01980e01a18?ixlib=rb-4.0.3&w=100&h=100&fit=crop"
    }
  ];

  return (
    <div className="pt-16">
      <section className="py-20 bg-gradient-to-br from-warm-gray to-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h1 className="text-4xl md:text-5xl font-bold text-deep-gray mb-6">Support Our Mission</h1>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Your generosity helps us provide essential support, resources, and community connections to families affected by autism
            </p>
          </div>

          {/* Impact Stats */}
          <div className="grid md:grid-cols-4 gap-6 mb-16">
            {impactStats.map((stat, index) => (
              <GlassCard key={index} className="text-center">
                <stat.icon className="w-12 h-12 text-primary mx-auto mb-4" />
                <div className="text-2xl font-bold text-deep-gray mb-2">{stat.value}</div>
                <div className="text-lg font-semibold text-deep-gray mb-2">{stat.label}</div>
                <p className="text-gray-600 text-sm">{stat.description}</p>
              </GlassCard>
            ))}
          </div>

          {/* How Your Donation Helps */}
          <div className="mb-16">
            <h2 className="text-3xl font-bold text-deep-gray text-center mb-12">How Your Donation Helps</h2>
            <div className="grid md:grid-cols-3 gap-8">
              <GlassCard className="text-center">
                <div className="w-16 h-16 bg-gradient-to-r from-primary to-secondary rounded-2xl flex items-center justify-center mx-auto mb-6">
                  <BookOpen className="text-white w-8 h-8" />
                </div>
                <h3 className="text-xl font-semibold text-deep-gray mb-4">Resource Development</h3>
                <p className="text-gray-600 mb-4">
                  60% of donations go directly to creating and maintaining our comprehensive library of evidence-based resources, tools, and educational materials.
                </p>
                <div className="bg-primary/10 rounded-lg p-3">
                  <p className="text-primary font-semibold">$100 = 20 new resources</p>
                </div>
              </GlassCard>

              <GlassCard className="text-center">
                <div className="w-16 h-16 bg-gradient-to-r from-secondary to-accent rounded-2xl flex items-center justify-center mx-auto mb-6">
                  <Users className="text-white w-8 h-8" />
                </div>
                <h3 className="text-xl font-semibold text-deep-gray mb-4">Community Support</h3>
                <p className="text-gray-600 mb-4">
                  25% funds our community programs, support groups, professional consultations, and moderated forums to connect families.
                </p>
                <div className="bg-secondary/10 rounded-lg p-3">
                  <p className="text-secondary font-semibold">$50 = 1 consultation session</p>
                </div>
              </GlassCard>

              <GlassCard className="text-center">
                <div className="w-16 h-16 bg-gradient-to-r from-accent to-primary rounded-2xl flex items-center justify-center mx-auto mb-6">
                  <TrendingUp className="text-white w-8 h-8" />
                </div>
                <h3 className="text-xl font-semibold text-deep-gray mb-4">Platform Innovation</h3>
                <p className="text-gray-600 mb-4">
                  15% supports technology improvements, new features, security, and platform maintenance to serve families better.
                </p>
                <div className="bg-accent/10 rounded-lg p-3">
                  <p className="text-accent font-semibold">$25 = Platform improvements</p>
                </div>
              </GlassCard>
            </div>
          </div>

          {/* Donation Form */}
          <div className="grid lg:grid-cols-2 gap-12 mb-16">
            <div>
              <Card className="shadow-lg border-0">
                <CardHeader>
                  <CardTitle className="text-2xl font-bold text-deep-gray flex items-center">
                    <Heart className="w-6 h-6 text-primary mr-3" />
                    Make a Donation
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <form onSubmit={handleSubmit} className="space-y-6">
                    {/* Donation Type */}
                    <div>
                      <label className="text-sm font-medium text-deep-gray mb-3 block">Donation Type</label>
                      <div className="grid grid-cols-2 gap-4">
                        <Button
                          type="button"
                          variant={donationType === "one-time" ? "default" : "outline"}
                          onClick={() => setDonationType("one-time")}
                          className="h-12"
                          data-testid="button-one-time"
                        >
                          <DollarSign className="w-4 h-4 mr-2" />
                          One-Time
                        </Button>
                        <Button
                          type="button"
                          variant={donationType === "monthly" ? "default" : "outline"}
                          onClick={() => setDonationType("monthly")}
                          className="h-12"
                          data-testid="button-monthly"
                        >
                          <Calendar className="w-4 h-4 mr-2" />
                          Monthly
                        </Button>
                      </div>
                    </div>

                    {/* Donation Amount */}
                    <div>
                      <label className="text-sm font-medium text-deep-gray mb-3 block">Donation Amount</label>
                      <div className="grid grid-cols-3 gap-3 mb-4">
                        {donationTiers.slice(0, 5).map((tier) => (
                          <Button
                            key={tier.amount}
                            type="button"
                            variant={donationAmount === tier.amount ? "default" : "outline"}
                            onClick={() => setDonationAmount(tier.amount)}
                            className="h-12"
                            data-testid={`button-amount-${tier.amount}`}
                          >
                            ${tier.amount}
                          </Button>
                        ))}
                      </div>
                      <Button
                        type="button"
                        variant={donationAmount === "custom" ? "default" : "outline"}
                        onClick={() => setDonationAmount("custom")}
                        className="w-full h-12 mb-3"
                        data-testid="button-custom-amount"
                      >
                        Custom Amount
                      </Button>
                      {donationAmount === "custom" && (
                        <div className="relative">
                          <span className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-500">$</span>
                          <Input
                            type="number"
                            placeholder="Enter amount"
                            value={customAmount}
                            onChange={(e) => setCustomAmount(e.target.value)}
                            className="pl-8"
                            data-testid="input-custom-amount"
                            min="1"
                            required
                          />
                        </div>
                      )}
                    </div>

                    {/* Donor Information */}
                    <div className="space-y-4">
                      <div className="grid grid-cols-2 gap-4">
                        <Input
                          placeholder="Full Name"
                          value={formData.name}
                          onChange={(e) => setFormData({...formData, name: e.target.value})}
                          data-testid="input-donor-name"
                          required
                        />
                        <Input
                          type="email"
                          placeholder="Email Address"
                          value={formData.email}
                          onChange={(e) => setFormData({...formData, email: e.target.value})}
                          data-testid="input-donor-email"
                          required
                        />
                      </div>
                      <Textarea
                        placeholder="Optional message or dedication..."
                        rows={3}
                        value={formData.message}
                        onChange={(e) => setFormData({...formData, message: e.target.value})}
                        data-testid="textarea-donor-message"
                      />
                    </div>

                    {/* Checkboxes */}
                    <div className="space-y-3">
                      <label className="flex items-center space-x-3">
                        <input
                          type="checkbox"
                          checked={formData.anonymous}
                          onChange={(e) => setFormData({...formData, anonymous: e.target.checked})}
                          className="rounded border-gray-300"
                          data-testid="checkbox-anonymous"
                        />
                        <span className="text-sm text-gray-600">Make this donation anonymous</span>
                      </label>
                      <label className="flex items-center space-x-3">
                        <input
                          type="checkbox"
                          checked={formData.newsletter}
                          onChange={(e) => setFormData({...formData, newsletter: e.target.checked})}
                          className="rounded border-gray-300"
                          data-testid="checkbox-newsletter"
                        />
                        <span className="text-sm text-gray-600">Subscribe to our newsletter</span>
                      </label>
                    </div>

                    <Button 
                      type="submit"
                      className="w-full bg-primary text-white hover:bg-primary/90 h-12 text-lg"
                      disabled={donationMutation.isPending}
                      data-testid="button-submit-donation"
                    >
                      <CreditCard className="w-5 h-5 mr-2" />
                      {donationMutation.isPending ? "Processing..." : `Donate $${donationAmount === "custom" ? customAmount || "0" : donationAmount}`}
                    </Button>
                  </form>
                </CardContent>
              </Card>
            </div>

            {/* Impact Preview */}
            <div className="space-y-6">
              <GlassCard>
                <h3 className="text-xl font-bold text-deep-gray mb-4 flex items-center">
                  <Target className="w-5 h-5 text-primary mr-2" />
                  Your Impact
                </h3>
                {donationAmount && donationAmount !== "custom" ? (
                  <div>
                    {donationTiers.find(tier => tier.amount === donationAmount) && (
                      <div className="space-y-3">
                        <div className="bg-primary/10 rounded-lg p-4">
                          <h4 className="font-semibold text-primary text-lg mb-2">
                            {donationTiers.find(tier => tier.amount === donationAmount)?.title}
                          </h4>
                          <p className="text-gray-700 mb-2">
                            {donationTiers.find(tier => tier.amount === donationAmount)?.description}
                          </p>
                          <p className="text-gray-600 text-sm">
                            {donationTiers.find(tier => tier.amount === donationAmount)?.impact}
                          </p>
                        </div>
                        {donationType === "monthly" && (
                          <div className="bg-secondary/10 rounded-lg p-4">
                            <h4 className="font-semibold text-secondary mb-2">Monthly Impact</h4>
                            <p className="text-gray-600 text-sm">
                              Your recurring donation will provide ongoing support and help us plan for long-term growth and sustainability.
                            </p>
                          </div>
                        )}
                      </div>
                    )}
                  </div>
                ) : (
                  <p className="text-gray-600">Select a donation amount to see your potential impact.</p>
                )}
              </GlassCard>

              <GlassCard>
                <h3 className="text-xl font-bold text-deep-gray mb-4">Tax Information</h3>
                <div className="space-y-3 text-sm text-gray-600">
                  <div className="flex items-start space-x-2">
                    <CheckCircle className="w-4 h-4 text-green-500 mt-0.5 flex-shrink-0" />
                    <span>All donations are tax-deductible (Tax ID: 12-3456789)</span>
                  </div>
                  <div className="flex items-start space-x-2">
                    <CheckCircle className="w-4 h-4 text-green-500 mt-0.5 flex-shrink-0" />
                    <span>You'll receive a tax receipt via email</span>
                  </div>
                  <div className="flex items-start space-x-2">
                    <CheckCircle className="w-4 h-4 text-green-500 mt-0.5 flex-shrink-0" />
                    <span>Secure processing with bank-level encryption</span>
                  </div>
                  <div className="flex items-start space-x-2">
                    <CheckCircle className="w-4 h-4 text-green-500 mt-0.5 flex-shrink-0" />
                    <span>Cancel recurring donations anytime</span>
                  </div>
                </div>
              </GlassCard>
            </div>
          </div>

          {/* Volunteer Opportunities */}
          <div className="mb-16">
            <h2 className="text-3xl font-bold text-deep-gray text-center mb-4">Other Ways to Help</h2>
            <p className="text-xl text-gray-600 text-center mb-12 max-w-2xl mx-auto">
              Can't donate right now? There are many other ways to support our mission and make a difference
            </p>
            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
              {volunteerOpportunities.map((opportunity, index) => (
                <GlassCard key={index} className="text-center">
                  <opportunity.icon className="w-12 h-12 text-primary mx-auto mb-4" />
                  <h3 className="text-lg font-semibold text-deep-gray mb-3">{opportunity.title}</h3>
                  <p className="text-gray-600 text-sm mb-4">{opportunity.description}</p>
                  <div className="space-y-2 text-xs text-gray-500">
                    <div className="flex items-center justify-center">
                      <Clock className="w-3 h-3 mr-1" />
                      {opportunity.time}
                    </div>
                    <p>Skills: {opportunity.skills}</p>
                  </div>
                  <Button 
                    size="sm" 
                    className="mt-4 w-full bg-secondary text-white hover:bg-secondary/90"
                    data-testid={`button-volunteer-${index}`}
                  >
                    Learn More
                  </Button>
                </GlassCard>
              ))}
            </div>
          </div>

          {/* Donor Testimonials */}
          <div className="mb-16">
            <h2 className="text-3xl font-bold text-deep-gray text-center mb-12">From Our Supporters</h2>
            <div className="grid md:grid-cols-3 gap-8">
              {testimonials.map((testimonial, index) => (
                <TestimonialCard
                  key={index}
                  name={testimonial.name}
                  role={testimonial.role}
                  content={testimonial.content}
                  rating={testimonial.rating}
                  imageUrl={testimonial.imageUrl}
                />
              ))}
            </div>
          </div>

          {/* Corporate Partnerships */}
          <div className="mb-16">
            <GlassCard>
              <div className="text-center">
                <h2 className="text-3xl font-bold text-deep-gray mb-4">Corporate Partnerships</h2>
                <p className="text-xl text-gray-600 mb-8 max-w-3xl mx-auto">
                  Partner with AutismConnect to support autism awareness and make a meaningful impact in your community
                </p>
                <div className="grid md:grid-cols-3 gap-6 mb-8">
                  <div className="text-center">
                    <HandHeart className="w-12 h-12 text-primary mx-auto mb-4" />
                    <h3 className="font-semibold text-deep-gray mb-2">Sponsorship Opportunities</h3>
                    <p className="text-gray-600 text-sm">Support our workshops, events, and resource development</p>
                  </div>
                  <div className="text-center">
                    <Users className="w-12 h-12 text-secondary mx-auto mb-4" />
                    <h3 className="font-semibold text-deep-gray mb-2">Employee Engagement</h3>
                    <p className="text-gray-600 text-sm">Volunteer programs and team building opportunities</p>
                  </div>
                  <div className="text-center">
                    <Globe className="w-12 h-12 text-accent mx-auto mb-4" />
                    <h3 className="font-semibold text-deep-gray mb-2">CSR Programs</h3>
                    <p className="text-gray-600 text-sm">Align with our mission for meaningful social impact</p>
                  </div>
                </div>
                <Button 
                  className="bg-primary text-white hover:bg-primary/90 px-8 py-3"
                  data-testid="button-corporate-partnership"
                >
                  Explore Partnerships
                </Button>
              </div>
            </GlassCard>
          </div>

          {/* Final CTA */}
          <div className="text-center">
            <div className="bg-gradient-to-r from-primary to-secondary rounded-2xl p-12">
              <h2 className="text-3xl font-bold text-white mb-4">Every Contribution Matters</h2>
              <p className="text-white/90 mb-8 text-lg max-w-2xl mx-auto">
                Whether it's $5 or $500, your donation directly impacts families and helps us build a more supportive world for individuals with autism.
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <Button 
                  className="bg-white text-primary hover:bg-gray-100 px-8 py-3"
                  onClick={() => window.scrollTo({ top: 400, behavior: 'smooth' })}
                  data-testid="button-donate-now"
                >
                  Donate Now
                </Button>
                <Button 
                  variant="outline"
                  className="border-white text-white hover:bg-white hover:text-primary px-8 py-3"
                  data-testid="button-learn-more-impact"
                >
                  Learn More About Our Impact
                </Button>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
