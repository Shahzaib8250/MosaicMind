import { HeroSection } from "@/components/ui/hero-section";
import { FeatureCard } from "@/components/ui/feature-card";
import { TestimonialCard } from "@/components/ui/testimonial-card";
import { Button } from "@/components/ui/button";
import { useQuery } from "@tanstack/react-query";
import { 
  TrendingUp, 
  GraduationCap, 
  Users, 
  Gauge, 
  Bell, 
  Shield,
  Apple,
  Play
} from "lucide-react";

export default function Home() {
  const { data: featuredTestimonials = [] } = useQuery({
    queryKey: ["/api/testimonials/featured"],
  });

  const features = [
    {
      icon: TrendingUp,
      title: "Progress Tracking",
      description: "Monitor development milestones and therapy progress with intuitive visual dashboards and reports.",
      gradient: "bg-gradient-to-r from-primary to-secondary",
    },
    {
      icon: GraduationCap,
      title: "Educational Resources",
      description: "Access curated learning materials, therapy guides, and expert-approved educational content.",
      gradient: "bg-gradient-to-r from-secondary to-accent",
    },
    {
      icon: Users,
      title: "Support Network",
      description: "Connect with other families, join support groups, and access professional guidance when needed.",
      gradient: "bg-gradient-to-r from-accent to-primary",
    },
    {
      icon: Gauge,
      title: "Personalized Dashboard",
      description: "Customized interface that adapts to your family's specific needs and preferences.",
      gradient: "bg-gradient-to-r from-primary-light to-secondary",
    },
    {
      icon: Bell,
      title: "Smart Notifications",
      description: "Gentle reminders for appointments, therapy sessions, and important milestones.",
      gradient: "bg-gradient-to-r from-secondary to-primary-light",
    },
    {
      icon: Shield,
      title: "Privacy & Security",
      description: "Your family's data is protected with enterprise-grade security and privacy controls.",
      gradient: "bg-gradient-to-r from-accent to-secondary",
    },
  ];

  return (
    <div>
      {/* Hero Section */}
      <HeroSection
        title="Supporting Families with"
        highlightText="Autism"
        subtitle="– All in One App"
        description="Comprehensive tools, resources, and community support to help families navigate their autism journey with confidence and connection."
      />

      {/* Features Overview */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16 animate-slide-up">
            <h2 className="text-3xl md:text-4xl font-bold text-deep-gray mb-4">
              Comprehensive Support Tools
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Everything families need to track progress, access resources, and connect with supportive communities.
            </p>
          </div>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {features.map((feature, index) => (
              <FeatureCard
                key={index}
                icon={feature.icon}
                title={feature.title}
                description={feature.description}
                gradient={feature.gradient}
              />
            ))}
          </div>
        </div>
      </section>

      {/* Testimonials Section */}
      <section className="py-20 bg-gradient-to-br from-warm-gray to-soft-gray">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-deep-gray mb-4">
              What Families Are Saying
            </h2>
            <p className="text-xl text-gray-600">
              Real stories from families who've found support and progress with AutismConnect.
            </p>
          </div>
          
          <div className="grid md:grid-cols-3 gap-8">
            {featuredTestimonials.length > 0 ? (
              featuredTestimonials.map((testimonial: any) => (
                <TestimonialCard
                  key={testimonial.id}
                  name={testimonial.name}
                  role={testimonial.role}
                  content={testimonial.content}
                  rating={testimonial.rating}
                  imageUrl={testimonial.imageUrl}
                />
              ))
            ) : (
              // Default testimonials when API data is not available
              [
                {
                  name: "Sarah M.",
                  role: "Parent of 7-year-old",
                  content: "This app has been a game-changer for our family. The progress tracking helps us see how far my son has come, and the community support is invaluable.",
                  rating: 5,
                  imageUrl: "https://images.unsplash.com/photo-1544005313-94ddf0286df2?ixlib=rb-4.0.3&w=100&h=100&fit=crop",
                },
                {
                  name: "Dr. James L.",
                  role: "Behavioral Therapist",
                  content: "I recommend AutismConnect to all my clients' families. The resources are evidence-based and the tracking tools help me provide better care.",
                  rating: 5,
                  imageUrl: "https://images.unsplash.com/photo-1582750433449-648ed127bb54?ixlib=rb-4.0.3&w=100&h=100&fit=crop",
                },
                {
                  name: "Maria R.",
                  role: "Special Education Teacher",
                  content: "The educational resources are fantastic! I use them in my classroom and share them with parents. It's created a wonderful bridge between home and school.",
                  rating: 5,
                  imageUrl: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-4.0.3&w=100&h=100&fit=crop",
                },
              ].map((testimonial, index) => (
                <TestimonialCard
                  key={index}
                  name={testimonial.name}
                  role={testimonial.role}
                  content={testimonial.content}
                  rating={testimonial.rating}
                  imageUrl={testimonial.imageUrl}
                />
              ))
            )}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-gradient-to-r from-primary to-secondary">
        <div className="max-w-4xl mx-auto text-center px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl md:text-4xl font-bold text-white mb-6">
            Ready to Start Your Journey?
          </h2>
          <p className="text-xl text-white/90 mb-8">
            Join thousands of families who've found support, progress, and community with AutismConnect.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button 
              className="bg-white text-primary px-8 py-4 h-auto text-lg font-medium hover-lift transition-all duration-300"
              data-testid="button-download-ios"
            >
              <Apple className="w-5 h-5 mr-2" />
              Download for iOS
            </Button>
            <Button 
              className="bg-white text-primary px-8 py-4 h-auto text-lg font-medium hover-lift transition-all duration-300"
              data-testid="button-download-android"
            >
              <Play className="w-5 h-5 mr-2" />
              Download for Android
            </Button>
          </div>
        </div>
      </section>
    </div>
  );
}
