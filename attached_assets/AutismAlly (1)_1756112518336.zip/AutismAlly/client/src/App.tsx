import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import Navbar from "@/components/layout/navbar";
import Footer from "@/components/layout/footer";

// Pages
import Home from "@/pages/home";
import About from "@/pages/about";
import Features from "@/pages/features";
import App from "@/pages/app";
import Categories from "@/pages/categories";
import Blog from "@/pages/blog";
import Resources from "@/pages/resources";
import Community from "@/pages/community";
import Services from "@/pages/services";
import Testimonials from "@/pages/testimonials";
import FAQ from "@/pages/faq";
import Donate from "@/pages/donate";
import NotFound from "@/pages/not-found";

function Router() {
  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      <main className="flex-1">
        <Switch>
          <Route path="/" component={Home} />
          <Route path="/about" component={About} />
          <Route path="/features" component={Features} />
          <Route path="/app" component={App} />
          <Route path="/categories" component={Categories} />
          <Route path="/blog" component={Blog} />
          <Route path="/resources" component={Resources} />
          <Route path="/community" component={Community} />
          <Route path="/services" component={Services} />
          <Route path="/testimonials" component={Testimonials} />
          <Route path="/faq" component={FAQ} />
          <Route path="/donate" component={Donate} />
          <Route component={NotFound} />
        </Switch>
      </main>
      <Footer />
    </div>
  );
}

function AppComponent() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        <Router />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default AppComponent;
