import { 
  type User, 
  type InsertUser,
  type BlogPost,
  type InsertBlogPost,
  type Resource,
  type InsertResource,
  type Testimonial,
  type InsertTestimonial,
  type SupportGroup,
  type InsertSupportGroup,
  type ContactSubmission,
  type InsertContactSubmission,
  type NewsletterSubscription,
  type InsertNewsletterSubscription
} from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  // Users
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;

  // Blog Posts
  getBlogPosts(limit?: number, category?: string): Promise<BlogPost[]>;
  getBlogPost(id: string): Promise<BlogPost | undefined>;
  createBlogPost(post: InsertBlogPost): Promise<BlogPost>;
  getFeaturedBlogPosts(): Promise<BlogPost[]>;

  // Resources
  getResources(category?: string, ageGroup?: string): Promise<Resource[]>;
  getResource(id: string): Promise<Resource | undefined>;
  createResource(resource: InsertResource): Promise<Resource>;
  getPopularResources(): Promise<Resource[]>;

  // Testimonials
  getTestimonials(): Promise<Testimonial[]>;
  getFeaturedTestimonials(): Promise<Testimonial[]>;
  createTestimonial(testimonial: InsertTestimonial): Promise<Testimonial>;

  // Support Groups
  getSupportGroups(): Promise<SupportGroup[]>;
  getSupportGroup(id: string): Promise<SupportGroup | undefined>;
  createSupportGroup(group: InsertSupportGroup): Promise<SupportGroup>;

  // Contact & Newsletter
  createContactSubmission(submission: InsertContactSubmission): Promise<ContactSubmission>;
  createNewsletterSubscription(subscription: InsertNewsletterSubscription): Promise<NewsletterSubscription>;
}

export class MemStorage implements IStorage {
  private users: Map<string, User>;
  private blogPosts: Map<string, BlogPost>;
  private resources: Map<string, Resource>;
  private testimonials: Map<string, Testimonial>;
  private supportGroups: Map<string, SupportGroup>;
  private contactSubmissions: Map<string, ContactSubmission>;
  private newsletterSubscriptions: Map<string, NewsletterSubscription>;

  constructor() {
    this.users = new Map();
    this.blogPosts = new Map();
    this.resources = new Map();
    this.testimonials = new Map();
    this.supportGroups = new Map();
    this.contactSubmissions = new Map();
    this.newsletterSubscriptions = new Map();
    
    this.seedData();
  }

  private seedData() {
    // Seed blog posts
    const blogPost1: BlogPost = {
      id: randomUUID(),
      title: "Breaking Communication Barriers: Visual Supports That Work",
      content: "Discover evidence-based visual communication strategies...",
      excerpt: "Discover evidence-based visual communication strategies that have helped thousands of families improve daily interactions and reduce frustration.",
      category: "Communication",
      author: "Dr. Emily Carter",
      authorRole: "Speech-Language Pathologist",
      imageUrl: "https://images.unsplash.com/photo-1527689368864-3a821dbccc34?ixlib=rb-4.0.3",
      readTime: 8,
      publishedAt: new Date(),
      featured: true,
    };
    this.blogPosts.set(blogPost1.id, blogPost1);

    // Seed testimonials
    const testimonial1: Testimonial = {
      id: randomUUID(),
      name: "Sarah M.",
      role: "Parent of 7-year-old",
      content: "This app has been a game-changer for our family. The progress tracking helps us see how far my son has come, and the community support is invaluable.",
      rating: 5,
      imageUrl: "https://images.unsplash.com/photo-1544005313-94ddf0286df2?ixlib=rb-4.0.3",
      featured: true,
      createdAt: new Date(),
    };
    this.testimonials.set(testimonial1.id, testimonial1);

    // Seed support groups
    const group1: SupportGroup = {
      id: randomUUID(),
      name: "New Parents Support",
      description: "Connect with other families navigating their first steps in the autism journey.",
      category: "New Parents",
      location: "Online",
      memberCount: 142,
      isOnline: true,
      createdAt: new Date(),
    };
    this.supportGroups.set(group1.id, group1);
  }

  // User methods
  async getUser(id: string): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(user => user.username === username);
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = randomUUID();
    const user: User = { 
      ...insertUser, 
      id,
      createdAt: new Date()
    };
    this.users.set(id, user);
    return user;
  }

  // Blog post methods
  async getBlogPosts(limit?: number, category?: string): Promise<BlogPost[]> {
    let posts = Array.from(this.blogPosts.values());
    
    if (category) {
      posts = posts.filter(post => post.category === category);
    }
    
    posts.sort((a, b) => new Date(b.publishedAt!).getTime() - new Date(a.publishedAt!).getTime());
    
    if (limit) {
      posts = posts.slice(0, limit);
    }
    
    return posts;
  }

  async getBlogPost(id: string): Promise<BlogPost | undefined> {
    return this.blogPosts.get(id);
  }

  async createBlogPost(insertPost: InsertBlogPost): Promise<BlogPost> {
    const id = randomUUID();
    const post: BlogPost = {
      ...insertPost,
      id,
      publishedAt: new Date(),
    };
    this.blogPosts.set(id, post);
    return post;
  }

  async getFeaturedBlogPosts(): Promise<BlogPost[]> {
    return Array.from(this.blogPosts.values()).filter(post => post.featured);
  }

  // Resource methods
  async getResources(category?: string, ageGroup?: string): Promise<Resource[]> {
    let resources = Array.from(this.resources.values());
    
    if (category) {
      resources = resources.filter(resource => resource.category === category);
    }
    
    if (ageGroup) {
      resources = resources.filter(resource => resource.ageGroup === ageGroup);
    }
    
    return resources.sort((a, b) => (b.downloads || 0) - (a.downloads || 0));
  }

  async getResource(id: string): Promise<Resource | undefined> {
    return this.resources.get(id);
  }

  async createResource(insertResource: InsertResource): Promise<Resource> {
    const id = randomUUID();
    const resource: Resource = {
      ...insertResource,
      id,
      createdAt: new Date(),
    };
    this.resources.set(id, resource);
    return resource;
  }

  async getPopularResources(): Promise<Resource[]> {
    return Array.from(this.resources.values())
      .sort((a, b) => (b.downloads || 0) - (a.downloads || 0))
      .slice(0, 6);
  }

  // Testimonial methods
  async getTestimonials(): Promise<Testimonial[]> {
    return Array.from(this.testimonials.values())
      .sort((a, b) => new Date(b.createdAt!).getTime() - new Date(a.createdAt!).getTime());
  }

  async getFeaturedTestimonials(): Promise<Testimonial[]> {
    return Array.from(this.testimonials.values()).filter(testimonial => testimonial.featured);
  }

  async createTestimonial(insertTestimonial: InsertTestimonial): Promise<Testimonial> {
    const id = randomUUID();
    const testimonial: Testimonial = {
      ...insertTestimonial,
      id,
      createdAt: new Date(),
    };
    this.testimonials.set(id, testimonial);
    return testimonial;
  }

  // Support group methods
  async getSupportGroups(): Promise<SupportGroup[]> {
    return Array.from(this.supportGroups.values())
      .sort((a, b) => (b.memberCount || 0) - (a.memberCount || 0));
  }

  async getSupportGroup(id: string): Promise<SupportGroup | undefined> {
    return this.supportGroups.get(id);
  }

  async createSupportGroup(insertGroup: InsertSupportGroup): Promise<SupportGroup> {
    const id = randomUUID();
    const group: SupportGroup = {
      ...insertGroup,
      id,
      createdAt: new Date(),
    };
    this.supportGroups.set(id, group);
    return group;
  }

  // Contact and newsletter methods
  async createContactSubmission(insertSubmission: InsertContactSubmission): Promise<ContactSubmission> {
    const id = randomUUID();
    const submission: ContactSubmission = {
      ...insertSubmission,
      id,
      submittedAt: new Date(),
    };
    this.contactSubmissions.set(id, submission);
    return submission;
  }

  async createNewsletterSubscription(insertSubscription: InsertNewsletterSubscription): Promise<NewsletterSubscription> {
    const id = randomUUID();
    const subscription: NewsletterSubscription = {
      ...insertSubscription,
      id,
      subscribedAt: new Date(),
    };
    this.newsletterSubscriptions.set(id, subscription);
    return subscription;
  }
}

export const storage = new MemStorage();
